document.getElementById("year").textContent = new Date().getFullYear();

// terms.html is a standalone document — it doesn't load app.js, so it can't
// use its data-action delegation (actionHandlers/delegateClick). Same
// conceptual pattern (data-action + a single delegated listener) so the CSP's
// script-src 'self' (no 'unsafe-inline') keeps working here too, just a
// smaller, page-local implementation instead of sharing app.js's dispatch
// table for a single action.
document.addEventListener("click", (e) => {
  const el = e.target.closest('[data-action="set-lang"]');
  if (!el) return;
  setLang(el.dataset.lang);
});
