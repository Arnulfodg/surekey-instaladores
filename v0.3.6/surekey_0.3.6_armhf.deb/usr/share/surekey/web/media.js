// web/media.js — shared implementation for the 4 standalone, independently
// password-gated file-browsing pages (fotos.html/videos.html/documentos.html/
// archivos.html). Deliberately NOT wired to app.js in any way (no shared
// sitesCache/actionHandlers/session state) — same conceptual pattern as
// app.js (data-action delegated click handling, CSP-safe, no inline
// style=""/on*="" attributes, escapeAttr() before interpolating any
// user-supplied string into HTML) but its own small, self-contained
// dispatch table, exactly the pattern web/terms.js already demonstrates at a
// tiny scale, just larger here since there's more surface to cover.
//
// Security model reminder (see CLAUDE.md and internal/api/media.go): the
// one-time per-category login is the ONLY password check in this whole
// feature. Every action after that — including deleting a folder or a file —
// needs only a plain "are you sure?" confirmation, never a re-typed
// password. That's why confirmSimple() below has no password field at all,
// unlike app.js's askConfirmation().

const category = document.body.dataset.category; // "photo" | "video" | "document" | "other"

// The single user's name, captured once at setup — same pattern app.js uses
// for created_by/updated_by stamps. Falls back to a generic label until
// /api/status answers (best-effort, no session required to read it).
let currentUserName = "SureKey";
fetch("/api/status")
  .then((r) => r.json())
  .then((s) => {
    if (s.full_name) currentUserName = s.full_name;
  })
  .catch(() => {});

// Which folder is currently open in #media-folder-modal (null when it's
// closed) — also doubles as "is the folder view or the root view active"
// for onLangChanged()/refresh-after-delete logic below.
let currentFolderId = null;
// Which file's metadata is currently shown in #media-file-modal.
let currentFile = null;
// Set by confirmSimple(), consumed (and cleared) by the confirm dialog's Yes
// button — see mediaConfirmYes().
let pendingConfirmAction = null;
// In-memory cache of the folder list (avoids a re-fetch just to show a
// folder's name in its own modal head) and an id->file index covering
// whichever file grids are currently rendered (root + open folder), so a
// card click can look up its full metadata without another round trip.
let foldersCache = [];
let filesById = {};

// Small inline icon set, matching app.js's ICONS in style (viewBox 0 0 16 16,
// stroke="currentColor", stroke-width 1.4) so the two never look visually
// inconsistent even though this file doesn't import app.js.
const ICONS = {
  eye: `<svg viewBox="0 0 16 16" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M1 8s2.5-4.5 7-4.5S15 8 15 8s-2.5 4.5-7 4.5S1 8 1 8Z"/><circle cx="8" cy="8" r="2"/></svg>`,
  eyeOff: `<svg viewBox="0 0 16 16" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M1 8s2.5-4.5 7-4.5S15 8 15 8s-2.5 4.5-7 4.5S1 8 1 8Z"/><circle cx="8" cy="8" r="2"/><path d="M2 2l12 12"/></svg>`,
  // Generic "file" glyph — the fallback shown for non-image files in card
  // thumbnails and in the file modal's "no preview available" state.
  file: `<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.3"><path d="M4 1.5h5.2L12.5 4.8V14.5H4Z"/><path d="M9.2 1.5V4.8H12.5"/></svg>`,
};

function genericIconMarkup() {
  return `<span class="media-file-icon">${ICONS.file}</span>`;
}

function escapeAttr(s) {
  return (s || "")
    .toString()
    .replace(/&/g, "&amp;")
    .replace(/"/g, "&quot;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function formatBytes(n) {
  if (typeof n !== "number" || isNaN(n)) return "";
  const units = ["B", "KB", "MB", "GB", "TB"];
  let v = n;
  let i = 0;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i++;
  }
  return `${v.toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
}

function formatDate(iso) {
  if (!iso) return "";
  const d = new Date(iso);
  return isNaN(d.getTime()) ? "" : d.toLocaleDateString();
}

// --- Fetch helpers ---
//
// mediaFetch/mediaJSON are this file's equivalent of app.js's api() — same
// "a 401 always means go back to the gate" principle, just independent
// per-category state instead of the vault's single session. login/logout
// deliberately do NOT go through these (see doMediaLogin/doMediaLogout):
// calling them before a session exists would immediately re-trigger the
// gate on the expected 401 from a failed login attempt, which is confusing
// rather than helpful.
async function mediaFetch(path, options = {}) {
  const res = await fetch(`/api/media/${category}${path}`, options);
  if (res.status === 401) {
    const body = await res.json().catch(() => ({}));
    showGate(translateApiError(body.error) || null);
    throw new Error("not authenticated");
  }
  return res;
}

async function mediaJSON(path, options = {}) {
  const res = await mediaFetch(path, { ...options, headers: { "Content-Type": "application/json", ...(options.headers || {}) } });
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(translateApiError(body.error) || `error ${res.status}`);
  return body;
}

// --- Gate / browser view toggling ---

function renderMediaStatus(unlocked) {
  const el = document.getElementById("media-status");
  if (!el) return;
  el.hidden = false;
  el.className = unlocked ? "lock-pill unlocked" : "lock-pill";
  el.textContent = unlocked ? t("media_status_unlocked") : t("media_status_locked");
}

function showGate(message) {
  document.getElementById("media-browser").hidden = true;
  document.getElementById("media-gate").hidden = false;
  document.getElementById("media-password").value = "";
  document.getElementById("media-gate-error").textContent = message || "";
  renderMediaStatus(false);
}

function showBrowser() {
  document.getElementById("media-gate").hidden = true;
  document.getElementById("media-browser").hidden = false;
  renderMediaStatus(true);
}

// --- Login / logout ---
//
// Deliberately bypasses mediaFetch/mediaJSON: a wrong-password attempt here
// is an *expected* 401 that should just show an inline error on the gate
// itself, not trigger mediaFetch's "force the gate back" 401 handler (which
// would be a confusing no-op, since the gate is already the only thing on
// screen at this point).
async function doMediaLogin() {
  const password = document.getElementById("media-password").value;
  const errEl = document.getElementById("media-gate-error");
  errEl.textContent = "";
  try {
    const res = await fetch(`/api/media/${category}/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password }),
    });
    const body = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(translateApiError(body.error) || `error ${res.status}`);
    document.getElementById("media-password").value = "";
    showBrowser();
    await loadRoot();
  } catch (e) {
    errEl.textContent = e.message;
  }
}

async function doMediaLogout() {
  try {
    await fetch(`/api/media/${category}/logout`, { method: "POST" });
  } catch (_) {
    // best-effort: even if this fails, still redirect below
  }
  window.location.href = "index.html";
}

// --- Action feedback (create folder / upload / backup / restore) ---
//
// Separate from #media-gate-error (which only ever applies to the login
// screen) and from #media-confirm-subtitle (which is reused per-confirmation)
// — this is the one place every already-authenticated action reports back to.
function clearActionFeedback() {
  document.getElementById("media-action-error").textContent = "";
  document.getElementById("media-action-message").textContent = "";
}

function showActionError(msg) {
  document.getElementById("media-action-message").textContent = "";
  document.getElementById("media-action-error").textContent = msg || "";
}

function showActionMessage(msg) {
  document.getElementById("media-action-error").textContent = "";
  document.getElementById("media-action-message").textContent = msg || "";
}

// --- Root view: folders + loose (unfiled) files ---

async function loadRoot() {
  currentFolderId = null;
  const [folders, files] = await Promise.all([mediaJSON("/folders"), mediaJSON("/files")]);
  foldersCache = folders || [];
  renderFolders(foldersCache);
  renderFileCards("media-loose-files", files || [], "media_no_loose_files");
}

function renderFolders(folders) {
  const grid = document.getElementById("media-folders");
  if (!folders || folders.length === 0) {
    grid.innerHTML = `<p class="muted">${t("media_no_folders")}</p>`;
    return;
  }
  grid.innerHTML = folders
    .map(
      (f) => `
      <button type="button" class="cred-card" data-action="media-open-folder" data-folder-id="${escapeAttr(f.id)}">
        <div class="cred-card-label">${escapeAttr(f.name)}</div>
        <div class="cred-card-meta">${escapeAttr(formatDate(f.created_at))}</div>
      </button>`
    )
    .join("");
}

function fileCardHtml(file) {
  const downloadUrl = `/api/media/${category}/files/${escapeAttr(file.id)}`;
  return `
    <div class="cred-card media-file-card">
      <button type="button" class="media-card-open" data-action="media-open-file" data-file-id="${escapeAttr(file.id)}">
        <div class="media-card-thumb" id="media-thumb-${escapeAttr(file.id)}">${genericIconMarkup()}</div>
        <div class="cred-card-label">${escapeAttr(file.original_filename)}</div>
        <div class="cred-card-meta">${escapeAttr(formatBytes(file.size_bytes))}</div>
      </button>
      <div class="media-card-actions">
        <a class="icon-btn" href="${downloadUrl}" download title="${t("btn_download")}" aria-label="${t("btn_download")}"><svg viewBox="0 0 16 16" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M8 1.5v8.2M5 7.2 8 10l3-2.8"/><path d="M2.5 12v1.3A1.2 1.2 0 0 0 3.7 14.5h8.6a1.2 1.2 0 0 0 1.2-1.2V12"/></svg></a>
        <button type="button" class="icon-btn danger-hover" data-action="media-quick-delete-file" data-file-id="${escapeAttr(file.id)}" title="${t("btn_delete")}" aria-label="${t("btn_delete")}"><svg viewBox="0 0 16 16" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M2.5 4.5h11M6 4.5V3a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v1.5M5 4.5l.6 8.4a1 1 0 0 0 1 .9h2.8a1 1 0 0 0 1-.9l.6-8.4"/></svg></button>
      </div>
    </div>`;
}

// Shared by the root "loose files" grid and the per-folder grid inside
// #media-folder-modal. Always renders the generic file icon first, then —
// only for image files, and only after a throwaway Image() confirms a
// thumbnail actually decoded — swaps in the real <img>. This is the
// CSP-safe equivalent of an inline onerror="" fallback (blocked by
// script-src/style-src 'self'): never assume the /thumbnail endpoint
// succeeds, since the backend 404s for anything not a decodable image
// (internal/api/media.go's handleThumbnail).
function renderFileCards(containerId, files, emptyKey) {
  const grid = document.getElementById(containerId);
  for (const f of files) filesById[f.id] = f;

  if (!files || files.length === 0) {
    grid.innerHTML = `<p class="muted">${t(emptyKey)}</p>`;
    return;
  }
  grid.innerHTML = files.map(fileCardHtml).join("");

  files.forEach((file) => {
    const mt = file.mime_type || "";
    if (!mt.startsWith("image/") || mt === "image/svg+xml") return; // svg excluded — matches the backend's own inline-safety allow-list
    const probe = new Image();
    probe.addEventListener("load", () => {
      const slot = document.getElementById(`media-thumb-${file.id}`);
      if (slot) slot.innerHTML = `<img src="${escapeAttr(probe.src)}" alt="">`;
    });
    probe.src = `/api/media/${category}/files/${file.id}/thumbnail`;
  });
}

// --- Folder modal ---

function openFolderModal(folderId) {
  currentFolderId = folderId;
  const folder = foldersCache.find((f) => f.id === folderId);
  document.getElementById("media-folder-name").textContent = folder ? folder.name : "";

  return mediaJSON(`/files?folder_id=${encodeURIComponent(folderId)}`).then((files) => {
    renderFileCards("media-folder-files", files || [], "media_no_folder_files");
    const dialog = document.getElementById("media-folder-modal");
    if (!dialog.open) {
      dialog.showModal();
      lockBodyScroll();
    }
  });
}

function closeFolderModal() {
  document.getElementById("media-folder-modal").close();
  currentFolderId = null;
  unlockBodyScrollIfNoModalsOpen();
}

function deleteFolder() {
  const folder = foldersCache.find((f) => f.id === currentFolderId);
  const name = folder ? folder.name : t("this_folder");
  const folderId = currentFolderId;
  confirmSimple(t("media_confirm_delete_folder_title"), t("media_confirm_delete_folder_body", { name }), async () => {
    await mediaFetch(`/folders/${folderId}`, { method: "DELETE" });
    document.getElementById("media-folder-modal").close();
    currentFolderId = null;
    unlockBodyScrollIfNoModalsOpen();
    await loadRoot();
  });
}

// --- File modal ---

function openFileModal(file) {
  currentFile = file;
  document.getElementById("media-file-name").textContent = file.original_filename;
  document.getElementById("media-file-meta").textContent = `${formatBytes(file.size_bytes)} · ${formatDate(file.created_at)}`;

  const url = `/api/media/${category}/files/${file.id}`;
  document.getElementById("media-file-download").href = url;

  const mt = file.mime_type || "";
  const previewEl = document.getElementById("media-file-preview");
  previewEl.className = "cred-modal-body media-preview";
  if (mt.startsWith("image/") && mt !== "image/svg+xml") {
    previewEl.innerHTML = `<img src="${escapeAttr(url)}" alt="${escapeAttr(file.original_filename)}">`;
  } else if (mt.startsWith("video/")) {
    previewEl.innerHTML = `<video src="${escapeAttr(url)}" controls></video>`;
  } else if (mt.startsWith("audio/")) {
    previewEl.innerHTML = `<audio src="${escapeAttr(url)}" controls></audio>`;
  } else if (mt === "application/pdf") {
    previewEl.innerHTML = `<iframe src="${escapeAttr(url)}" title="${escapeAttr(file.original_filename)}"></iframe>`;
  } else {
    previewEl.innerHTML = `${genericIconMarkup()}<p class="hint">${t("media_no_preview")}</p>`;
  }

  const dialog = document.getElementById("media-file-modal");
  if (!dialog.open) {
    dialog.showModal();
    lockBodyScroll();
  }
}

function closeFileModal() {
  document.getElementById("media-file-modal").close();
  currentFile = null;
  unlockBodyScrollIfNoModalsOpen();
}

// Shared by both the file modal's delete button (deleteFile(), acting on
// currentFile) and each card's own quick-delete button (quickDeleteFile(id),
// acting on whichever file id was clicked) — same confirm/delete/refresh
// logic either way, just different lookups for which file and what to close
// afterward.
function quickDeleteFile(fileId) {
  const file = filesById[fileId];
  const name = file ? file.original_filename : t("this_file");
  confirmSimple(t("media_confirm_delete_file_title"), t("media_confirm_delete_file_body", { name }), async () => {
    await mediaFetch(`/files/${fileId}`, { method: "DELETE" });
    // If the file being deleted is the one currently open in the file
    // modal, close it too — its card is gone either way, and leaving the
    // modal open referencing a just-deleted file would be stale.
    if (currentFile && currentFile.id === fileId) {
      document.getElementById("media-file-modal").close();
      currentFile = null;
      unlockBodyScrollIfNoModalsOpen();
    }
    // Reload whichever view is active: the deleted file's card is stale
    // either way, regardless of whether it lived in the root "loose files"
    // grid or inside an open folder.
    if (currentFolderId) await openFolderModal(currentFolderId);
    else await loadRoot();
  });
}

function deleteFile() {
  if (!currentFile) return;
  quickDeleteFile(currentFile.id);
}

function openFileById(fileId) {
  const file = filesById[fileId];
  if (file) openFileModal(file);
}

// --- Create folder / upload / backup / restore ---

async function createFolder() {
  const input = document.getElementById("media-new-folder-name");
  const name = input.value.trim();
  clearActionFeedback();
  if (!name) return;
  try {
    await mediaJSON("/folders", { method: "POST", body: JSON.stringify({ name, created_by: currentUserName }) });
    input.value = "";
    await loadRoot();
  } catch (e) {
    showActionError(e.message);
  }
}

// Uploads every selected file sequentially (simpler, and avoids overwhelming
// a Raspberry Pi with several multi-GB uploads in parallel) via plain
// fetch() with a FormData body — never set Content-Type manually here, the
// browser sets the multipart boundary itself. folderId is null/undefined for
// a loose/root upload, a folder id string for an in-folder upload.
async function uploadFiles(fileInputEl, folderId) {
  const files = Array.from(fileInputEl.files || []);
  if (files.length === 0) return;
  for (const file of files) {
    const fd = new FormData();
    fd.append("file", file);
    fd.append("created_by", currentUserName);
    if (folderId !== null && folderId !== undefined) fd.append("folder_id", folderId);
    const res = await mediaFetch("/files", { method: "POST", body: fd });
    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      throw new Error(translateApiError(body.error) || `error ${res.status}`);
    }
  }
  fileInputEl.value = "";
  if (folderId !== null && folderId !== undefined) await openFolderModal(folderId);
  else await loadRoot();
}

async function handleUploadRoot() {
  clearActionFeedback();
  try {
    await uploadFiles(document.getElementById("media-upload-input-root"), null);
  } catch (e) {
    showActionError(e.message);
  }
}

async function handleUploadFolder() {
  clearActionFeedback();
  try {
    await uploadFiles(document.getElementById("media-upload-input-folder"), currentFolderId);
  } catch (e) {
    showActionError(e.message);
  }
}

// The backup endpoint is a POST (not a plain link/navigation) — this is the
// standard idiom for triggering a file download from a POST response:
// fetch() it, read the body as a blob, then click a throwaway <a> pointed at
// an object URL for it.
async function backupCategory() {
  clearActionFeedback();
  try {
    const res = await mediaFetch("/backup", { method: "POST" });
    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      throw new Error(translateApiError(body.error) || `error ${res.status}`);
    }
    const blob = await res.blob();
    const match = (res.headers.get("Content-Disposition") || "").match(/filename="?([^"]+)"?/);
    const filename = match ? match[1] : `surekey-${category}-backup.zip`;
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  } catch (e) {
    showActionError(e.message);
  }
}

function triggerRestore() {
  document.getElementById("media-restore-input").click();
}

async function restoreBackup(fileInputEl) {
  const file = fileInputEl.files && fileInputEl.files[0];
  clearActionFeedback();
  if (!file) return;
  try {
    const fd = new FormData();
    fd.append("backup", file);
    fd.append("created_by", currentUserName);
    const res = await mediaFetch("/restore", { method: "POST", body: fd });
    const body = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(translateApiError(body.error) || `error ${res.status}`);
    fileInputEl.value = "";
    showActionMessage(t(body.imported === 1 ? "media_restore_success_one" : "media_restore_success_other", { count: body.imported }));
    await loadRoot();
  } catch (e) {
    showActionError(e.message);
  }
}

// --- No-password confirm dialog ---
//
// Deliberately much simpler than app.js's askConfirmation (no password field
// at all) — see the file header comment for why: this feature's whole
// design is that only the one-time category login is a password check.
function confirmSimple(title, subtitle, onConfirm) {
  document.getElementById("media-confirm-title").textContent = title;
  document.getElementById("media-confirm-subtitle").textContent = subtitle;
  pendingConfirmAction = onConfirm;
  document.getElementById("media-confirm-dialog").showModal();
}

async function mediaConfirmYes(btn) {
  if (!pendingConfirmAction) return;
  btn.disabled = true;
  try {
    const action = pendingConfirmAction;
    pendingConfirmAction = null;
    await action();
    document.getElementById("media-confirm-dialog").close();
  } catch (e) {
    // Leave the dialog open with the error visible, same principle as
    // app.js's confirmSubmit — so the user sees exactly what went wrong
    // instead of it vanishing into an already-closed dialog.
    document.getElementById("media-confirm-subtitle").textContent = e.message;
  } finally {
    btn.disabled = false;
  }
}

function mediaConfirmCancel() {
  document.getElementById("media-confirm-dialog").close();
  pendingConfirmAction = null;
}

// --- Password field show/hide toggle (only one such field on these pages) ---

function toggleMediaPw(btn) {
  const input = document.getElementById("media-password");
  const showing = input.type === "text";
  input.type = showing ? "password" : "text";
  btn.innerHTML = showing ? ICONS.eye : ICONS.eyeOff;
  btn.setAttribute("aria-label", showing ? t("show_password") : t("hide_password"));
}

// Static .pw-toggle button starts empty (its markup can't call JS at parse
// time) — fill it in once here, same pattern as app.js.
document.querySelectorAll(".pw-toggle").forEach((btn) => (btn.innerHTML = ICONS.eye));

// --- Body-scroll lock for the two singleton full-screen modals ---
//
// Same reasoning as app.js's own lockBodyScroll/unlockBodyScrollIfNoModalsOpen:
// dialog.cred-modal is a fixed/100dvh overlay, but that alone doesn't stop
// the underlying <body> from still scrolling behind it.

function lockBodyScroll() {
  document.body.classList.add("modal-open");
}

function unlockBodyScrollIfNoModalsOpen() {
  const anyOpen = document.getElementById("media-folder-modal")?.open || document.getElementById("media-file-modal")?.open;
  if (!anyOpen) document.body.classList.remove("modal-open");
}

// --- Delegated click handling (CSP-safe: no onclick="" anywhere) ---

const actionHandlers = {
  "set-lang": (el) => setLang(el.dataset.lang),
  "toggle-media-pw": (el) => toggleMediaPw(el),
  "media-login": () => doMediaLogin(),
  "media-logout": () => doMediaLogout(),
  "media-backup": () => backupCategory(),
  "media-trigger-restore": () => triggerRestore(),
  "media-create-folder": () => createFolder(),
  "media-open-folder": (el) => openFolderModal(el.dataset.folderId),
  "media-close-folder-modal": () => closeFolderModal(),
  "media-delete-folder": () => deleteFolder(),
  "media-upload-folder": () => handleUploadFolder(),
  "media-open-file": (el) => openFileById(el.dataset.fileId),
  "media-close-file-modal": () => closeFileModal(),
  "media-delete-file": () => deleteFile(),
  "media-quick-delete-file": (el) => quickDeleteFile(el.dataset.fileId),
  "media-upload-root": () => handleUploadRoot(),
  "media-confirm-yes": (el) => mediaConfirmYes(el),
  "media-confirm-cancel": () => mediaConfirmCancel(),
};

document.addEventListener("click", (e) => {
  const el = e.target.closest("[data-action]");
  if (!el) return;
  const handler = actionHandlers[el.dataset.action];
  if (handler) handler(el, e);
});

document.addEventListener("change", (e) => {
  if (e.target.id === "media-restore-input") restoreBackup(e.target);
});

document.addEventListener("submit", (e) => {
  if (e.target.closest("[data-prevent-submit]")) e.preventDefault();
});

// --- Language switch: re-render whichever view is active ---
//
// applyTranslations() (i18n.js) already re-applies every static data-i18n
// attribute on its own — this only needs to cover text built from template
// literals via t() (the lock-pill's status text, and the folders/files
// grids' "nothing here yet" empty states), matching app.js's own
// onLangChanged().
function onLangChanged() {
  if (!document.getElementById("media-browser").hidden) {
    renderMediaStatus(true);
    if (currentFolderId) openFolderModal(currentFolderId);
    else loadRoot();
  } else if (!document.getElementById("media-gate").hidden) {
    renderMediaStatus(false);
  }
}

// --- Initial load ---
//
// A reload with an already-valid, non-expired category cookie skips
// straight to the browser view without re-prompting — that's correct and
// intended, the cookie IS the "already proved you know the password" state
// for the rest of this session's idle-timeout window. Only logout/expiry
// re-triggers the gate (handled by mediaFetch's 401 branch above).
loadRoot()
  .then(() => showBrowser())
  .catch(() => {
    // mediaFetch/mediaJSON already called showGate() on a 401; any other
    // failure (network error, 500, ...) is also safest left showing the
    // gate rather than a half-rendered browser view.
  });
