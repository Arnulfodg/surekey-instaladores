const CONFIRM_MESSAGE = "confirmo la actualización";
// Distinct from CONFIRM_MESSAGE on purpose: everywhere else the app sends a
// fixed phrase the user never sees or types. Restoring a backup wipes the
// entire vault in one shot, so this one has to be typed by hand each time —
// this constant only exists for client-side feedback before the round trip;
// the server (internal/api/import.go's importConfirmPhrase) enforces it too.
const IMPORT_CONFIRM_PHRASE = "REEMPLAZAR TODO";

// Small inline icon set — keeps the UI free of emoji and external font/
// icon requests (nothing to fetch, nothing to leak) while staying compact
// enough for dense credential rows.
const ICONS = {
  eye: `<svg viewBox="0 0 16 16" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M1 8s2.5-4.5 7-4.5S15 8 15 8s-2.5 4.5-7 4.5S1 8 1 8Z"/><circle cx="8" cy="8" r="2"/></svg>`,
  eyeOff: `<svg viewBox="0 0 16 16" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M1 8s2.5-4.5 7-4.5S15 8 15 8s-2.5 4.5-7 4.5S1 8 1 8Z"/><circle cx="8" cy="8" r="2"/><path d="M2 2l12 12"/></svg>`,
  pencil: `<svg viewBox="0 0 16 16" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M11 2l3 3-8 8-3.5.5.5-3.5 8-8Z"/></svg>`,
  trash: `<svg viewBox="0 0 16 16" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M2.5 4.5h11M6 4.5V3a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v1.5M5 4.5l.6 8.4a1 1 0 0 0 1 .9h2.8a1 1 0 0 0 1-.9l.6-8.4"/></svg>`,
  copy: `<svg viewBox="0 0 16 16" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.4"><rect x="5.5" y="5.5" width="8" height="9" rx="1.3"/><path d="M3 10.5V3.8A1.3 1.3 0 0 1 4.3 2.5H10"/></svg>`,
  check: `<svg viewBox="0 0 16 16" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M2.5 8.5l3.5 3.5 7-8"/></svg>`,
  lock: `<svg viewBox="0 0 16 16" width="11" height="11" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="7" width="10" height="7" rx="1.5"/><path d="M5 7V5a3 3 0 0 1 6 0v2"/></svg>`,
  unlock: `<svg viewBox="0 0 16 16" width="11" height="11" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="7" width="10" height="7" rx="1.5"/><path d="M5 7V5a3 3 0 0 1 5.5-1.9"/></svg>`,
  chevron: `<svg viewBox="0 0 16 16" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><path d="M5.5 3l5 5-5 5"/></svg>`,
  dice: `<svg viewBox="0 0 16 16" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.4"><rect x="2" y="2" width="12" height="12" rx="2.5"/><circle cx="5.5" cy="5.5" r="0.9" fill="currentColor" stroke="none"/><circle cx="10.5" cy="5.5" r="0.9" fill="currentColor" stroke="none"/><circle cx="8" cy="8" r="0.9" fill="currentColor" stroke="none"/><circle cx="5.5" cy="10.5" r="0.9" fill="currentColor" stroke="none"/><circle cx="10.5" cy="10.5" r="0.9" fill="currentColor" stroke="none"/></svg>`,
  refresh: `<svg viewBox="0 0 16 16" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M13 4.5A5.5 5.5 0 1 0 14 8"/><path d="M13 1.5v3.5h-3.5"/></svg>`,
  close: `<svg viewBox="0 0 16 16" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M3 3l10 10M13 3L3 13"/></svg>`,
};

function togglePw(inputId, btn) {
  const input = document.getElementById(inputId);
  const showing = input.type === "text";
  input.type = showing ? "password" : "text";
  btn.innerHTML = showing ? ICONS.eye : ICONS.eyeOff;
  btn.setAttribute("aria-label", showing ? t("show_password") : t("hide_password"));
}

// Static .pw-toggle buttons in index.html start empty (their markup can't
// call JS at parse time) — fill them in once here.
document.querySelectorAll(".pw-toggle").forEach((btn) => (btn.innerHTML = ICONS.eye));
document.querySelectorAll(".gen-refresh-btn").forEach((btn) => (btn.innerHTML = ICONS.refresh));

// --- Delegación de eventos (sin atributos on*="" inline, para poder
// quitar 'unsafe-inline' de la CSP) ---
//
// Un solo listener por tipo de evento en vez de uno por elemento: cubre
// tanto el HTML estático (index.html) como el que se genera dinámicamente
// (renderSiteModalBody, renderSuggestions, etc.) sin tener que re-adjuntar nada
// cada vez que se vuelve a pintar algo. Cada elemento interactivo declara
// qué hacer vía data-action (clic), data-input-action, data-change-action,
// data-focus-action o data-blur-action, en vez de onclick="..." etc.
// focus/blur no burbujean de forma nativa — se delega con focusin/focusout,
// que sí burbujean, para lograr el mismo efecto que onfocus/onblur.
//
// Las funciones referenciadas abajo (cancelConfirm, doLogin, etc.) están
// definidas más adelante en este archivo como `function` — quedan
// "hoisted", así que ya existen para cuando el usuario dispara el primer
// evento, aunque este objeto se construya antes en el orden del archivo.
const actionHandlers = {
  "apply-search": () => applySearch(),
  "cancel-confirm": () => cancelConfirm(),
  "cancel-login-totp": () => cancelLoginTOTP(),
  "cancel-totp-setup": () => cancelTOTPSetup(),
  "change-master-password": () => changeMasterPassword(),
  "check-for-updates": (el) => checkForUpdatesNow(el),
  "close-generator": () => closeGenerator(),
  "confirm-submit": (el) => confirmSubmit(el),
  "confirm-totp-setup": () => confirmTOTPSetup(),
  "create-site": () => createSite(),
  "disable-totp": () => disableTOTP(),
  "dismiss-donate-popup": () => dismissDonatePopup(),
  "dismiss-password-reminder": () => dismissPasswordReminder(),
  "dismiss-update-banner": () => dismissUpdateBanner(),
  "do-login": () => doLogin(),
  "do-login-totp": () => doLoginTOTP(),
  "do-setup": () => doSetup(),
  "export-backup": () => exportBackup(),
  "import-backup": (el) => importBackup(el),
  "hide-suggestions": () => hideSuggestionsSoon(),
  "logout": () => logout(),
  "open-update-url": () => openUpdateURL(),
  "regenerate": () => regenerate(),
  "save-idle-timeout": (el) => saveIdleTimeout(el),
  "save-reminder-weeks": (el) => saveReminderWeeks(el),
  "set-lang": (el) => setLang(el.dataset.lang),
  "show-admin": () => showAdmin(),
  "show": (el) => show(el.dataset.target),
  "show-recovery": () => showRecovery(),
  "toggle-auto-update-check": (el) => toggleAutoUpdateCheck(el),
  "start-totp-setup": () => startTOTPSetup(),
  "submit-recovery": () => submitRecovery(),
  "select-all": (el) => el.select(),
  "toggle-pw": (el) => togglePw(el.dataset.target, el),
  "use-generated-password": () => useGeneratedPassword(),
  "reveal-password": (el) => revealPassword(el.dataset.credId, el),
  "copy-password": (el) => copyPassword(el.dataset.credId, el),
  "open-update-form": (el) => openUpdateForm(el.dataset.credId, el.dataset.siteId),
  "delete-credential": (el) => deleteCredential(el.dataset.credId),
  "open-cred-modal": (el) => openCredModal(el.dataset.credId, el.dataset.siteId),
  "close-cred-modal": () => closeCredModal(),
  "open-site-modal": (el) => openSiteModal(el.dataset.siteId),
  "close-site-modal": () => closeSiteModal(),
  "delete-site": (el) => deleteSite(el.dataset.siteId),
  "open-generator": (el) => openGenerator(el.dataset.target),
  "create-credential": (el) => createCredential(el.dataset.siteId),
  "jump-to-site": (el) => jumpToSite(el.dataset.siteId),
  "submit-update": (el) => submitUpdate(el.dataset.credId),
};

function delegateClick() {
  document.addEventListener("click", (e) => {
    const el = e.target.closest("[data-action]");
    if (!el) return;
    if (el.dataset.stopPropagation !== undefined) {
      e.stopPropagation();
      e.preventDefault();
    }
    const handler = actionHandlers[el.dataset.action];
    if (handler) handler(el, e);
  });
}

function delegateInput() {
  document.addEventListener("input", (e) => {
    const el = e.target.closest("[data-input-action]");
    if (!el) return;
    const handler = actionHandlers[el.dataset.inputAction];
    if (handler) handler(el, e);
  });
}

function delegateChange() {
  document.addEventListener("change", (e) => {
    const el = e.target.closest("[data-change-action]");
    if (!el) return;
    const handler = actionHandlers[el.dataset.changeAction];
    if (handler) handler(el, e);
  });
}

// focus/blur no burbujean — focusin/focusout son sus equivalentes que sí lo
// hacen, necesarios para delegar en document en vez de escuchar en cada
// campo individualmente (como hacían onfocus="..."/onblur="...").
function delegateFocus() {
  document.addEventListener("focusin", (e) => {
    const el = e.target.closest("[data-focus-action]");
    if (!el) return;
    const handler = actionHandlers[el.dataset.focusAction];
    if (handler) handler(el, e);
  });
}

function delegateBlur() {
  document.addEventListener("focusout", (e) => {
    const el = e.target.closest("[data-blur-action]");
    if (!el) return;
    const handler = actionHandlers[el.dataset.blurAction];
    if (handler) handler(el, e);
  });
}

delegateClick();
delegateInput();
delegateChange();
delegateFocus();
delegateBlur();

document.addEventListener("submit", (e) => {
  if (e.target.closest("[data-prevent-submit]")) e.preventDefault();
});

// Both the vault and the admin panel require an unlocked session — this is
// "am I in one of those two views right now", used by the 401 handler and
// the idle watcher so neither only fires for the vault.
function isAuthedViewActive() {
  return (
    document.getElementById("app-section").classList.contains("active") ||
    document.getElementById("admin-section").classList.contains("active")
  );
}

async function api(path, options = {}) {
  const res = await fetch(path, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
  });
  const body = await res.json().catch(() => ({}));
  // 401 only ever means "not authenticated / session expired" (see
  // internal/api/middleware.go) — confirm-password mismatches use 403
  // instead precisely so they don't land here. Any 401 while an authed
  // view was showing means the session died server-side (idle timeout,
  // restart, etc.) between actions, so force the login screen immediately
  // instead of leaving a stale, half-broken panel on screen.
  if (res.status === 401 && isAuthedViewActive()) {
    endSession(translateApiError(body.error) || t("session_expired_fallback"));
  }
  if (!res.ok) throw new Error(translateApiError(body.error) || `error ${res.status}`);
  return body;
}

function show(id) {
  document.querySelectorAll("section").forEach((s) => s.classList.remove("active"));
  document.getElementById(id).classList.add("active");
  if (id === "setup-section") renderLockPill("hidden");
  else if (id === "login-section" || id === "recovery-section") renderLockPill("locked");
  else renderLockPill("unlocked"); // app-section or admin-section

  // Always land back on the password step, never mid-way through a TOTP
  // prompt, whenever login-section is (re)shown — e.g. after logout, after
  // a session-expiry redirect, or after a password reset/recovery.
  if (id === "login-section") {
    document.getElementById("login-totp-panel").classList.add("js-hidden");
    document.getElementById("login-password-panel").classList.remove("js-hidden");
  }

  // El popup de donación vive en las pantallas "principales" (lo primero
  // que ve cualquiera al abrir SureKey: iniciar sesión, configuración
  // inicial, o ya la bóveda si la sesión seguía activa) — no en
  // recuperación (ya es un momento suficientemente estresante) ni en
  // administración. Se reprograma cada vez que se entra a una de estas
  // pantallas y se oculta al salir de ellas.
  if (DONATE_POPUP_SCREENS.has(id)) scheduleDonatePopup();
  else hideDonatePopup();
}

function showAdmin() {
  show("admin-section");
  loadSecuritySection();
  loadTOTPSection();
  loadUpdateSection();
  loadAccessLog();
}

// The header pill is the one place the UI states, plainly, what the vault's
// actual security status is right now — including a live countdown to the
// same auto-lock the idle watcher below enforces, so "cierra por
// inactividad" isn't just a claim, it's visibly ticking down.
function renderLockPill(state) {
  const el = document.getElementById("lock-status");
  if (!el) return;
  if (state === "hidden") {
    el.classList.add("js-hidden");
    return;
  }
  el.classList.remove("js-hidden");
  if (state === "locked") {
    el.className = "lock-pill";
    el.innerHTML = `${ICONS.lock} ${t("lock_pill_locked")}`;
    return;
  }
  el.className = "lock-pill unlocked";
  const remainingMs = Math.max(0, idleTimeoutMs - (Date.now() - lastActivity));
  const mm = Math.floor(remainingMs / 60000);
  const ss = Math.floor((remainingMs % 60000) / 1000)
    .toString()
    .padStart(2, "0");
  el.innerHTML = `${ICONS.unlock} ${t("lock_pill_unlocked")} ${mm}:${ss}`;
}

// The single user's name, captured once at setup — every credential/site
// created or edited from here on is stamped with this automatically, so
// nobody has to type "who am I" on every save (see refreshStatus/doLogin).
let currentUserName = "";

// Whether the server says the configured password-change reminder is
// overdue, and whether the user already dismissed the banner for this
// session. Both in-memory only: the banner should reappear on the next
// login while still overdue (see doLogin()).
let passwordChangeDue = false;
let passwordReminderDismissed = false;

// La versión instalada (viene de /api/status, disponible incluso sin
// sesión) y, si la hay, la versión más reciente publicada — se muestran
// juntas y de forma permanente en el footer de la página principal, a
// diferencia del banner/popup de arriba que son avisos descartables.
let currentVersion = "";

function renderFooterVersion() {
  const versionEl = document.getElementById("footer-version");
  if (versionEl) versionEl.textContent = currentVersion || "…";

  const avail = document.getElementById("footer-update-available");
  if (!avail) return;
  if (updateStatus && updateStatus.update_available) {
    document.getElementById("footer-latest-version").textContent = updateStatus.latest_version;
    document.getElementById("footer-update-link").href = updateStatus.latest_url || "#";
    avail.hidden = false;
  } else {
    avail.hidden = true;
  }
}

async function refreshStatus() {
  const status = await api("/api/status");
  if (status.idle_timeout_seconds) idleTimeoutMs = status.idle_timeout_seconds * 1000;
  currentUserName = status.full_name || "";
  passwordChangeDue = !!status.password_change_due;
  currentVersion = status.version || "";
  renderFooterVersion();
  return status;
}

function updatePasswordReminderBanner() {
  const banner = document.getElementById("password-reminder-banner");
  if (!banner) return;
  banner.classList.toggle("js-hidden", !(passwordChangeDue && !passwordReminderDismissed));
}

function dismissPasswordReminder() {
  passwordReminderDismissed = true;
  updatePasswordReminderBanner();
}

// --- Popup de donación ---
//
// A propósito se comporta como un anuncio: reaparece cada vez que el
// usuario entra a una pantalla "principal" (login, configuración inicial,
// o ya la bóveda), no solo la primera vez — ver show(). La única forma de
// detenerlo es cerrarlo con la X (o "Ahora no"), lo que lo apaga por el
// resto de esta sesión; una nueva sesión (nuevo login) lo reactiva. El
// retraso es mínimo (no cero) para que la animación de entrada
// (donate-in) se note como tal en vez de aparecer ya renderizado antes de
// que la pantalla termine de pintarse.
const DONATE_POPUP_SCREENS = new Set(["login-section", "setup-section", "app-section"]);
const DONATE_POPUP_DELAY_MS = 400;
let donatePopupDismissed = false;
let donatePopupTimer = null;

function scheduleDonatePopup() {
  clearTimeout(donatePopupTimer);
  if (donatePopupDismissed) return;
  donatePopupTimer = setTimeout(() => {
    const popup = document.getElementById("donate-popup");
    const stillOnDonateScreen = [...DONATE_POPUP_SCREENS].some((id) => document.getElementById(id).classList.contains("active"));
    if (popup && stillOnDonateScreen) popup.hidden = false;
  }, DONATE_POPUP_DELAY_MS);
}

function hideDonatePopup() {
  clearTimeout(donatePopupTimer);
  const popup = document.getElementById("donate-popup");
  if (popup) popup.hidden = true;
}

function dismissDonatePopup() {
  donatePopupDismissed = true;
  hideDonatePopup();
}

// --- Aviso de nueva versión disponible ---
//
// El chequeo real contra GitHub ocurre en el servidor (en segundo plano,
// ver internal/updatecheck), no aquí — el frontend solo lee el resultado
// cacheado (GET /api/updates/status) y decide si mostrar el banner. Igual
// que el recordatorio de contraseña, "Recordar más tarde" solo lo oculta
// por esta sesión: si sigue desactualizado, reaparece en el próximo login.
let updateStatus = null;
let updateBannerDismissed = false;

async function loadUpdateStatus() {
  try {
    updateStatus = await api("/api/updates/status");
  } catch (e) {
    updateStatus = null;
  }
  renderUpdateBanner();
}

function renderUpdateBanner() {
  const banner = document.getElementById("update-available-banner");
  if (banner) {
    const shouldShow = !!(updateStatus && updateStatus.update_available && !updateBannerDismissed);
    banner.classList.toggle("js-hidden", !shouldShow);
    if (shouldShow) {
      document.getElementById("update-version-label").textContent = ` (${updateStatus.latest_version})`;
    }
  }
  renderFooterVersion();
}

function dismissUpdateBanner() {
  updateBannerDismissed = true;
  renderUpdateBanner();
}

function openUpdateURL() {
  if (updateStatus && updateStatus.latest_url) window.open(updateStatus.latest_url, "_blank", "noopener");
}

// Called by setLang() (see i18n.js) right after applyTranslations() runs —
// that only handles static data-i18n attributes, so anything built from a
// template literal (the sites/credentials list, the admin sub-panels) needs
// to be re-rendered from the already-cached data instead of re-fetched, so
// switching language never requires a round trip or a page reload.
function onLangChanged() {
  // The lock-pill's text is built from t() calls, not data-i18n attributes
  // (it also carries a live countdown) — refresh it here too, otherwise it
  // only catches up on its next 1s tick from the idle-timeout interval below.
  if (isAuthedViewActive()) renderLockPill("unlocked");
  else if (["login-section", "recovery-section"].some((id) => document.getElementById(id).classList.contains("active"))) renderLockPill("locked");

  if (document.getElementById("app-section").classList.contains("active")) applySearch();
  if (document.getElementById("admin-section").classList.contains("active")) {
    loadSecuritySection();
    loadTOTPSection();
    loadUpdateSection();
    loadAccessLog();
  }
}

async function init() {
  document.getElementById("footer-year").textContent = new Date().getFullYear();
  const status = await refreshStatus();
  if (!status.setup) return show("setup-section");
  if (!status.logged_in) return show("login-section");
  show("app-section");
  updatePasswordReminderBanner();
  loadSites();
  loadUpdateStatus();
  markActivity();
}

// --- Cierre de sesión por inactividad ---
//
// El servidor ya expira la sesión en memoria tras IdleTimeout (ver
// internal/auth/session.go) y cualquier llamada posterior devuelve 401
// (manejado arriba). Pero sin esto, la pantalla se queda tal cual estaba
// hasta la próxima acción del usuario. Este temporizador la fuerza a
// cerrar del lado del cliente en cuanto se cumple el mismo plazo, sin
// esperar a que el usuario intente algo y falle.
let idleTimeoutMs = 15 * 60 * 1000;
let lastActivity = Date.now();

function markActivity() {
  lastActivity = Date.now();
}

["mousemove", "mousedown", "keydown", "touchstart", "scroll"].forEach((evt) =>
  document.addEventListener(evt, markActivity, { passive: true })
);

setInterval(() => {
  if (!isAuthedViewActive()) return;
  renderLockPill("unlocked"); // refresh the visible countdown
  if (Date.now() - lastActivity > idleTimeoutMs) {
    endSession(t("idle_timeout_message"));
  }
}, 1000);

let endingSession = false;
async function endSession(message) {
  if (endingSession) return; // avoid piling up logout calls from concurrent 401s
  endingSession = true;
  sitesCache = [];
  document.getElementById("sites-list").innerHTML = "";
  // Idle timeout (or any background 401) can fire while a <dialog> is still
  // open — e.g. mid-edit on a credential when the phone was set down. show()
  // below only toggles which <section> is .active, it never touches a
  // <dialog>, so without this the dialog stays [open] and body.modal-open
  // (see lockBodyScroll/unlockBodyScrollIfNoModalsOpen) stays stuck forever,
  // freezing scroll on whatever renders behind it — the page looks "frozen"
  // until a manual reload.
  ["confirm-dialog", "cred-modal", "site-modal", "generator-dialog"].forEach((id) => {
    const dialog = document.getElementById(id);
    if (dialog?.open) dialog.close();
  });
  document.body.classList.remove("modal-open");
  try {
    await api("/api/logout", { method: "POST" });
  } catch (_) {
    // best-effort: even if this fails, still lock the UI below
  }
  show("login-section");
  document.getElementById("login-password").value = "";
  document.getElementById("login-error").textContent = message || "";
  endingSession = false;
}

async function doSetup() {
  const full_name = document.getElementById("setup-fullname").value;
  const recovery_email = document.getElementById("setup-email").value;
  const password = document.getElementById("setup-password").value;
  const question_1 = document.getElementById("setup-question-1").value;
  const answer_1 = document.getElementById("setup-answer-1").value;
  const question_2 = document.getElementById("setup-question-2").value;
  const answer_2 = document.getElementById("setup-answer-2").value;
  const errEl = document.getElementById("setup-error");
  errEl.textContent = "";
  try {
    await api("/api/setup", {
      method: "POST",
      body: JSON.stringify({ full_name, recovery_email, password, question_1, answer_1, question_2, answer_2 }),
    });
    show("login-section");
  } catch (e) {
    errEl.textContent = e.message;
  }
}

async function showRecovery() {
  show("recovery-section");
  document.getElementById("recovery-error").textContent = "";
  const formEl = document.getElementById("recovery-form");
  const unavailableEl = document.getElementById("recovery-unavailable");
  try {
    const questions = await api("/api/recovery/questions");
    if (!questions.configured) {
      formEl.classList.add("js-hidden");
      unavailableEl.classList.remove("js-hidden");
      return;
    }
    formEl.classList.remove("js-hidden");
    unavailableEl.classList.add("js-hidden");
    document.getElementById("recovery-q1-label").textContent = questions.question_1;
    document.getElementById("recovery-q2-label").textContent = questions.question_2;
    [
      "recovery-answer-1",
      "recovery-answer-2",
      "recovery-new-password",
      "recovery-new-question-1",
      "recovery-new-answer-1",
      "recovery-new-question-2",
      "recovery-new-answer-2",
    ].forEach((id) => (document.getElementById(id).value = ""));
  } catch (e) {
    formEl.classList.add("js-hidden");
    unavailableEl.classList.remove("js-hidden");
    unavailableEl.textContent = e.message;
  }
}

async function submitRecovery() {
  const errEl = document.getElementById("recovery-error");
  errEl.textContent = "";
  const body = {
    answer_1: document.getElementById("recovery-answer-1").value,
    answer_2: document.getElementById("recovery-answer-2").value,
    new_password: document.getElementById("recovery-new-password").value,
    new_question_1: document.getElementById("recovery-new-question-1").value,
    new_answer_1: document.getElementById("recovery-new-answer-1").value,
    new_question_2: document.getElementById("recovery-new-question-2").value,
    new_answer_2: document.getElementById("recovery-new-answer-2").value,
  };
  try {
    await api("/api/recovery/reset", { method: "POST", body: JSON.stringify(body) });
    // No auto-login: performRecoveryReset already destroyed every session
    // server-side, so the user proves they memorized the new password by
    // logging in with it normally, same as any other fresh login.
    show("login-section");
    document.getElementById("login-error").textContent = t("password_reset_success");
  } catch (e) {
    errEl.textContent = e.message;
  }
}

async function doLogin() {
  const password = document.getElementById("login-password").value;
  const errEl = document.getElementById("login-error");
  errEl.textContent = "";
  try {
    const res = await api("/api/login", { method: "POST", body: JSON.stringify({ password }) });
    document.getElementById("login-password").value = "";
    if (res.totp_required) {
      document.getElementById("login-password-panel").classList.add("js-hidden");
      document.getElementById("login-totp-panel").classList.remove("js-hidden");
      document.getElementById("login-totp-code").value = "";
      document.getElementById("login-totp-error").textContent = "";
      document.getElementById("login-totp-code").focus();
      return;
    }
    await finishLogin();
  } catch (e) {
    errEl.textContent = e.message;
  }
}

// The password step and the (optional) TOTP step both end here: this is
// exactly what doLogin() used to do unconditionally before 2FA existed.
async function finishLogin() {
  passwordReminderDismissed = false; // fresh session: show the reminder again if still overdue
  updateBannerDismissed = false; // fresh session: show the update banner again if still outdated
  donatePopupDismissed = false; // fresh session: the donate popup can show again
  await refreshStatus();
  show("app-section");
  updatePasswordReminderBanner();
  markActivity();
  loadSites();
  loadUpdateStatus();
}

function cancelLoginTOTP() {
  document.getElementById("login-totp-panel").classList.add("js-hidden");
  document.getElementById("login-password-panel").classList.remove("js-hidden");
}

async function doLoginTOTP() {
  const code = document.getElementById("login-totp-code").value;
  const errEl = document.getElementById("login-totp-error");
  errEl.textContent = "";
  try {
    await api("/api/login/totp", { method: "POST", body: JSON.stringify({ code }) });
    document.getElementById("login-totp-code").value = "";
    document.getElementById("login-totp-panel").classList.add("js-hidden");
    document.getElementById("login-password-panel").classList.remove("js-hidden");
    await finishLogin();
  } catch (e) {
    errEl.textContent = e.message;
  }
}

async function logout() {
  await endSession("");
}

// In-memory cache of everything currently loaded, so the search box can
// filter instantly without a round trip per keystroke.
let sitesCache = [];

// Which site's full-screen modal is currently open, if any — lets loadSites()
// keep it in sync live (e.g. after adding a credential from inside it)
// instead of leaving stale data behind in an open modal.
let activeSiteId = null;

async function loadSites() {
  const sites = await api("/api/sites");
  sitesCache = await Promise.all(
    (sites || []).map(async (site) => ({
      site,
      // The API returns null (not []) when a site has zero credentials —
      // normalize once here so every consumer of sitesCache can assume an
      // array, instead of every callsite needing its own null guard.
      credentials: (await api(`/api/sites/${site.id}/credentials`)) || [],
    }))
  );
  applySearch();
  if (activeSiteId) {
    const entry = sitesCache.find((e) => e.site.id === activeSiteId);
    if (entry) renderSiteModalBody(entry.site, entry.credentials);
    else closeSiteModal(); // the active site itself was deleted from elsewhere
  }
}

function renderSitesList(entries) {
  const list = document.getElementById("sites-list");
  list.className = "creds-grid";
  list.innerHTML = entries.map((entry) => siteCardHtml(entry.site, entry.credentials)).join("");
}

function siteCardHtml(site, creds) {
  const count = (creds || []).length;
  return `
    <button type="button" class="cred-card" data-action="open-site-modal" data-site-id="${site.id}">
      <div class="cred-card-label">${escapeAttr(site.name)}</div>
      ${site.url ? `<div class="cred-card-meta">${escapeAttr(site.url)}</div>` : ""}
      <div class="site-count">${count} ${count === 1 ? t("credential_singular") : t("credential_plural")}</div>
    </button>`;
}

// Renders the exact same body content the old inline .site-body used to
// (creds-grid + add-credential form + update-form target), but into the
// singleton #site-modal's body instead of a per-site <details> element.
function renderSiteModalBody(site, creds) {
  const credsHtml = (creds || [])
    .map(
      (c) => `
      <button type="button" class="cred-card" data-action="open-cred-modal" data-cred-id="${c.id}" data-site-id="${site.id}">
        <div class="cred-card-label">${escapeAttr(c.label) || t("no_label")}</div>
        <div class="cred-card-meta">${escapeAttr([c.username, c.email].filter(Boolean).join(" · ")) || "—"}</div>
      </button>`
    )
    .join("");

  document.getElementById("site-modal-body").innerHTML = `
    <div id="creds-${site.id}" class="creds-grid">${credsHtml}</div>
    <details class="add-panel">
      <summary>${t("add_credential_to")} ${escapeAttr(site.name)}</summary>
      <div class="panel">
        <label class="field-label" for="cred-label-${site.id}">${t("label_label")}</label>
        <input id="cred-label-${site.id}" placeholder="${t("placeholder_label_example")}">
        <label class="field-label" for="cred-username-${site.id}">${t("label_username")}</label>
        <input id="cred-username-${site.id}" placeholder="${t("label_username")}">
        <label class="field-label" for="cred-email-${site.id}">${t("label_email")}</label>
        <input id="cred-email-${site.id}" placeholder="${t("label_email")}">
        <label class="field-label" for="cred-password-${site.id}">${t("label_password")}</label>
        <div class="pw-field has-generator">
          <input id="cred-password-${site.id}" type="password" placeholder="${t("label_password")}">
          <button type="button" class="pw-toggle pw-generate" data-action="open-generator" data-target="cred-password-${site.id}" title="${t("generator_title")}" aria-label="${t("generator_title")}">${ICONS.dice}</button>
          <button type="button" class="pw-toggle" data-action="toggle-pw" data-target="cred-password-${site.id}" aria-label="${t("show_password")}">${ICONS.eye}</button>
        </div>
        <label class="field-label" for="cred-notes-${site.id}">${t("label_notes_optional")}</label>
        <textarea id="cred-notes-${site.id}" placeholder="${t("label_notes_optional")}"></textarea>
        <button class="primary" data-action="create-credential" data-site-id="${site.id}">${t("btn_save_credential")}</button>
      </div>
    </details>
    <div id="update-form-${site.id}"></div>
  `;
}

// Both full-screen modals (#cred-modal, #site-modal) are position:fixed/
// 100dvh overlays, but that alone doesn't stop the underlying <body> from
// still scrolling behind them (rubber-band/overscroll artifacts on touch
// devices). These two helpers toggle a body-level class to lock/unlock
// background scroll, re-reading both dialogs' `.open` state at call time
// so the nested case (site-modal open, then cred-modal opened on top of
// it, then cred-modal closed) correctly leaves the body locked as long as
// site-modal is still open.
function lockBodyScroll() {
  document.body.classList.add("modal-open");
}

function unlockBodyScrollIfNoModalsOpen() {
  const anyOpen = document.getElementById("cred-modal")?.open || document.getElementById("site-modal")?.open;
  if (!anyOpen) document.body.classList.remove("modal-open");
}

// Singleton full-screen modal opened from a site card click, mirroring the
// same pattern #cred-modal already uses one level down.
function openSiteModal(siteId) {
  const entry = sitesCache.find((e) => e.site.id === siteId);
  if (!entry) return;
  activeSiteId = siteId;
  document.getElementById("site-modal-name").textContent = entry.site.name;
  document.getElementById("site-modal-url").textContent = entry.site.url || "";
  document.getElementById("site-modal-delete").dataset.siteId = siteId;
  renderSiteModalBody(entry.site, entry.credentials);
  document.getElementById("site-modal").showModal();
  lockBodyScroll();
}

function closeSiteModal() {
  document.getElementById("site-modal").close();
  activeSiteId = null;
  unlockBodyScrollIfNoModalsOpen();
}

function normalize(s) {
  return (s || "").toString().toLowerCase();
}

function entryMatches(entry, q) {
  if (!q) return true;
  if (normalize(entry.site.name).includes(q) || normalize(entry.site.url).includes(q)) return true;
  return entry.credentials.some(
    (c) => normalize(c.label).includes(q) || normalize(c.username).includes(q) || normalize(c.email).includes(q)
  );
}

// Predictive search: filters the visible site list on every keystroke and,
// in parallel, shows a dropdown of the best individual matches (site or
// credential) so you can jump straight to one without scrolling.
function applySearch() {
  const q = normalize(document.getElementById("search-input")?.value.trim());
  renderSitesList(sitesCache.filter((e) => entryMatches(e, q)));
  renderSuggestions(q);
}

function renderSuggestions(q) {
  const box = document.getElementById("search-suggestions");
  if (!box) return;
  if (!q) {
    box.classList.remove("open");
    box.innerHTML = "";
    return;
  }

  const results = [];
  for (const entry of sitesCache) {
    const site = entry.site;
    if (normalize(site.name).includes(q) || normalize(site.url).includes(q)) {
      results.push({ type: t("tag_site"), label: site.name, hint: site.url, siteId: site.id });
    }
    for (const c of entry.credentials) {
      if (normalize(c.label).includes(q) || normalize(c.username).includes(q) || normalize(c.email).includes(q)) {
        results.push({
          type: t("tag_credential"),
          label: c.label || c.username || c.email || t("no_label"),
          hint: `${site.name} · ${c.username || c.email || ""}`,
          siteId: site.id,
        });
      }
    }
  }

  if (results.length === 0) {
    box.innerHTML = `<div class="suggestion muted">${t("no_results")}</div>`;
  } else {
    box.innerHTML = results
      .slice(0, 6)
      .map(
        (r) => `
        <div class="suggestion" data-action="jump-to-site" data-site-id="${r.siteId}">
          <span class="tag">${r.type}</span>
          <strong>${escapeAttr(r.label)}</strong>
          <span class="muted">${escapeAttr(r.hint) || ""}</span>
        </div>`
      )
      .join("");
  }
  box.classList.add("open");
}

function jumpToSite(siteId) {
  document.getElementById("search-input").value = "";
  applySearch();
  openSiteModal(siteId);
}

function hideSuggestionsSoon() {
  // Delay so a click on a suggestion registers before the dropdown closes.
  setTimeout(() => document.getElementById("search-suggestions")?.classList.remove("open"), 150);
}

async function createSite() {
  const name = document.getElementById("new-site-name").value;
  const url = document.getElementById("new-site-url").value;
  const site = await api("/api/sites", { method: "POST", body: JSON.stringify({ name, url, created_by: currentUserName }) });
  document.getElementById("new-site-name").value = "";
  document.getElementById("new-site-url").value = "";
  await loadSites();
  openSiteModal(site.id); // open it right away — you'll likely add a credential next
}

async function createCredential(siteId) {
  const label = document.getElementById(`cred-label-${siteId}`).value;
  const username = document.getElementById(`cred-username-${siteId}`).value;
  const email = document.getElementById(`cred-email-${siteId}`).value;
  const password = document.getElementById(`cred-password-${siteId}`).value;
  const notes = document.getElementById(`cred-notes-${siteId}`).value;
  await api(`/api/sites/${siteId}/credentials`, {
    method: "POST",
    body: JSON.stringify({ label, username, email, password, notes, created_by: currentUserName }),
  });
  loadSites();
}

// Every credential decrypt (reveal, copy, opening the edit form) goes
// through this one call, which always asks for the master password first —
// viewing a secret is exactly as sensitive as changing or deleting one.
function revealWithConfirmation(credId, subtitle, action, onSuccess) {
  askConfirmation(
    subtitle,
    (confirm_password) => api(`/api/credentials/${credId}/reveal`, { method: "POST", body: JSON.stringify({ confirm_password, action }) }),
    onSuccess
  );
}

// Singleton full-screen modal opened from a .cred-card click. Only one
// credential's details are ever shown at a time, so the modal's password
// span is given the same id (`pw-${credId}`) the existing reveal/copy flow
// already expects — that's what lets revealPassword/copyPassword keep
// working completely unmodified.
function openCredModal(credId, siteId) {
  const entry = sitesCache.find((e) => e.site.id === siteId);
  const cred = entry?.credentials.find((c) => c.id === credId);
  if (!cred) return;

  document.getElementById("cred-modal-site").textContent = entry.site.name;
  document.getElementById("cred-modal-label").textContent = cred.label || t("no_label");
  document.getElementById("cred-modal-meta").textContent = [cred.username, cred.email].filter(Boolean).join(" · ") || "—";

  // Look this up by its stable class, not by its id: the id gets rewritten
  // below to `pw-${credId}` (so the existing revealPassword/copyPassword can
  // find it), which would make a later document.getElementById("cred-modal-password")
  // return null on the modal's second and subsequent opens.
  const pwEl = document.querySelector("#cred-modal .pw-reveal");
  pwEl.id = `pw-${credId}`;
  pwEl.textContent = "••••••••";
  pwEl.dataset.revealed = "false";
  setModalNotes("");

  const modal = document.getElementById("cred-modal");
  for (const el of modal.querySelectorAll("[data-cred-id]")) el.dataset.credId = credId;
  modal.querySelector('[data-action="open-update-form"]').dataset.siteId = siteId;

  // Reset the reveal button back to its masked ("eye") state on every open
  // — otherwise a previously revealed credential's eye-off icon could leak
  // onto a different credential when the shared modal reopens.
  const revealBtn = modal.querySelector('[data-action="reveal-password"]');
  revealBtn.innerHTML = ICONS.eye;
  revealBtn.title = t("view_password");
  revealBtn.setAttribute("aria-label", t("view_password"));

  modal.showModal();
  lockBodyScroll();
}

function closeCredModal() {
  document.getElementById("cred-modal").close();
  unlockBodyScrollIfNoModalsOpen();
}

// Notes are encrypted exactly like the password, so they only ever appear
// in the modal alongside a revealed password (same /reveal response) and
// are cleared again whenever it's re-masked or the modal reopens.
function setModalNotes(notes) {
  document.getElementById("cred-modal-notes-text").textContent = notes || "";
  document.getElementById("cred-modal-notes").hidden = !notes;
}

// Toggling the password back OFF never needs confirmation — it's just
// re-masking something already on screen, not a new decrypt.
function revealPassword(credId, btn) {
  const span = document.getElementById(`pw-${credId}`);
  if (span.dataset.revealed === "true") {
    span.textContent = "••••••••";
    span.dataset.revealed = "false";
    setModalNotes("");
    btn.innerHTML = ICONS.eye;
    btn.title = t("view_password");
    btn.setAttribute("aria-label", t("view_password"));
    return;
  }

  revealWithConfirmation(credId, t("confirm_view_password"), "view", (cred) => {
    span.textContent = cred.password;
    span.dataset.revealed = "true";
    setModalNotes(cred.notes);
    btn.innerHTML = ICONS.eyeOff;
    btn.title = t("hide_password");
    btn.setAttribute("aria-label", t("hide_password"));
  });
}

function copyPassword(credId, btn) {
  revealWithConfirmation(credId, t("confirm_copy_password"), "copy", async (cred) => {
    try {
      await navigator.clipboard.writeText(cred.password);
      flashCopyFeedback(btn, false);
    } catch (e) {
      flashCopyFeedback(btn, true);
    }
  });
}

function flashCopyFeedback(btn, failed) {
  const original = btn.innerHTML;
  btn.innerHTML = failed ? "!" : ICONS.check;
  btn.title = failed ? t("copy_failed") : t("copy_success");
  btn.classList.toggle("danger", failed);
  setTimeout(() => {
    btn.innerHTML = original;
    btn.title = t("copy_password");
    btn.classList.remove("danger");
  }, 1200);
}

function escapeAttr(s) {
  return (s || "")
    .toString()
    .replace(/&/g, "&amp;")
    .replace(/"/g, "&quot;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

// Opening the edit form no longer requires revealing the password first:
// label/username/email are already known from sitesCache (never secret),
// and password/notes are now optional opt-in fields in the form itself (see
// renderUpdateForm) — the partial PUT lets the backend keep whatever the
// user doesn't type a replacement for, so there's no need to decrypt and
// resend the existing secret unchanged just to edit a label.
function openUpdateForm(credId, siteId) {
  document.getElementById("cred-modal")?.close();
  const entry = sitesCache.find((e) => e.site.id === siteId);
  const meta = entry?.credentials.find((c) => c.id === credId);
  if (!meta) return;
  renderUpdateForm(credId, siteId, meta);
}

function renderUpdateForm(credId, siteId, meta) {
  const target = document.getElementById(`update-form-${siteId}`);
  target.innerHTML = `
    <div class="panel">
      <p class="eyebrow mb-sm">${t("editing_credential")}</p>
      <label class="field-label" for="upd-label-${credId}">${t("label_label")}</label>
      <input id="upd-label-${credId}" placeholder="${t("label_label")}" value="${escapeAttr(meta.label)}">
      <label class="field-label" for="upd-username-${credId}">${t("label_username")}</label>
      <input id="upd-username-${credId}" placeholder="${t("label_username")}" value="${escapeAttr(meta.username)}">
      <label class="field-label" for="upd-email-${credId}">${t("label_email")}</label>
      <input id="upd-email-${credId}" placeholder="${t("label_email")}" value="${escapeAttr(meta.email)}">
      <label class="field-label" for="upd-password-${credId}">${t("label_password")}</label>
      <div class="pw-field has-generator">
        <input id="upd-password-${credId}" type="password" placeholder="${t("placeholder_new_password")}">
        <button type="button" class="pw-toggle pw-generate" data-action="open-generator" data-target="upd-password-${credId}" title="${t("generator_title")}" aria-label="${t("generator_title")}">${ICONS.dice}</button>
        <button type="button" class="pw-toggle" data-action="toggle-pw" data-target="upd-password-${credId}" aria-label="${t("show_password")}">${ICONS.eye}</button>
      </div>
      <p class="hint">${t("hint_leave_password_unchanged")}</p>
      <label class="field-label" for="upd-notes-${credId}">${t("label_notes")}</label>
      <textarea id="upd-notes-${credId}" placeholder="${t("label_notes")}"></textarea>
      <label class="row gap-sm">
        <input type="checkbox" id="upd-clear-notes-${credId}">
        <span>${t("label_clear_notes")}</span>
      </label>
      <button class="primary" data-action="submit-update" data-cred-id="${credId}">${t("btn_update_will_confirm")}</button>
    </div>
  `;
}

// --- Generador de contraseñas ---
//
// Randomness comes from crypto.getRandomValues (Web Crypto), never
// Math.random() — the latter is not a CSPRNG and has no place generating
// secrets in a password manager. One character from each selected category
// is guaranteed up front so a length-20 password with all four options on
// can't come back missing symbols just by bad luck, then everything is
// shuffled so those guaranteed picks aren't predictably at the front.
const GEN_CHARSETS = {
  lower: "abcdefghijklmnopqrstuvwxyz",
  upper: "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
  digits: "0123456789",
  symbols: "!@#$%^&*()-_=+[]{};:,.<>?/~",
};

function secureRandomInt(maxExclusive) {
  const arr = new Uint32Array(1);
  crypto.getRandomValues(arr);
  return arr[0] % maxExclusive;
}

function generatePassword(length, opts) {
  const groups = Object.keys(GEN_CHARSETS).filter((k) => opts[k]).map((k) => GEN_CHARSETS[k]);
  if (groups.length === 0) return "";

  const pool = groups.join("");
  const chars = groups.map((g) => g[secureRandomInt(g.length)]);
  for (let i = chars.length; i < length; i++) chars.push(pool[secureRandomInt(pool.length)]);

  for (let i = chars.length - 1; i > 0; i--) {
    const j = secureRandomInt(i + 1);
    [chars[i], chars[j]] = [chars[j], chars[i]];
  }
  return chars.slice(0, length).join("");
}

let generatorTargetId = null;

function openGenerator(targetInputId) {
  generatorTargetId = targetInputId;
  regenerate();
  document.getElementById("generator-dialog").showModal();
}

function regenerate() {
  const length = parseInt(document.getElementById("gen-length").value, 10);
  document.getElementById("gen-length-value").textContent = length;

  const opts = {
    lower: document.getElementById("gen-lower").checked,
    upper: document.getElementById("gen-upper").checked,
    digits: document.getElementById("gen-digits").checked,
    symbols: document.getElementById("gen-symbols").checked,
  };
  const errEl = document.getElementById("gen-error");
  const preview = document.getElementById("gen-preview");

  if (!opts.lower && !opts.upper && !opts.digits && !opts.symbols) {
    errEl.textContent = t("gen_error_select_type");
    preview.value = "";
    return;
  }
  errEl.textContent = "";
  preview.value = generatePassword(length, opts);
}

function useGeneratedPassword() {
  const value = document.getElementById("gen-preview").value;
  if (!value || !generatorTargetId) return;
  const target = document.getElementById(generatorTargetId);
  target.value = value;
  target.classList.add("copy-flash-ok");
  setTimeout(() => target.classList.remove("copy-flash-ok"), 900);
  document.getElementById("generator-dialog").close();
  generatorTargetId = null;
}

function closeGenerator() {
  document.getElementById("generator-dialog").close();
  generatorTargetId = null;
}

// The confirm dialog is the single choke point every sensitive action goes
// through: viewing a password, copying one, editing, deleting a credential,
// deleting a whole site. `run(confirm_password)` makes the actual request;
// `onSuccess(result)` decides what happens with the response (reveal a
// password inline, refresh the list, etc.) — they differ per action, which
// is why both are passed in rather than hardcoded here.
//
// The dialog only closes itself on success. On failure (wrong confirmation
// password, missing fields, session expired, etc.) it stays open with the
// error visible, so the user can fix it and retry without redoing whatever
// they were doing. Previously the dialog closed the instant "Confirmar" was
// clicked, *before* the request was even sent, so any error from the server
// landed inside an already-closed, invisible dialog.
let pendingConfirm = null;

function askConfirmation(subtitle, run, onSuccess) {
  pendingConfirm = { run, onSuccess };
  document.getElementById("confirm-subtitle").textContent = subtitle;
  const dialog = document.getElementById("confirm-dialog");
  document.getElementById("confirm-password").value = "";
  document.getElementById("confirm-error").textContent = "";
  dialog.showModal();
}

function cancelConfirm() {
  document.getElementById("confirm-dialog").close();
  pendingConfirm = null;
}

async function confirmSubmit(btn) {
  if (!pendingConfirm) return;
  const confirm_password = document.getElementById("confirm-password").value;
  const errEl = document.getElementById("confirm-error");
  errEl.textContent = "";
  btn.disabled = true;
  try {
    const result = await pendingConfirm.run(confirm_password);
    document.getElementById("confirm-dialog").close();
    const onSuccess = pendingConfirm.onSuccess;
    pendingConfirm = null;
    if (onSuccess) await onSuccess(result);
  } catch (e) {
    errEl.textContent = e.message;
  } finally {
    btn.disabled = false;
  }
}

function submitUpdate(credId) {
  const label = document.getElementById(`upd-label-${credId}`).value;
  const username = document.getElementById(`upd-username-${credId}`).value;
  const email = document.getElementById(`upd-email-${credId}`).value;
  const password = document.getElementById(`upd-password-${credId}`).value;
  const notes = document.getElementById(`upd-notes-${credId}`).value;
  const clearNotes = document.getElementById(`upd-clear-notes-${credId}`).checked;

  const body = {
    label,
    username,
    email,
    updated_by: currentUserName,
    confirm_message: CONFIRM_MESSAGE,
  };
  // password/notes are omitted entirely unless the user actually typed
  // something (or, for notes, explicitly checked "clear") — the backend's
  // partial PUT treats an omitted field as "leave unchanged", so this is
  // what actually avoids overwriting the existing secret with garbage when
  // the field was never meant to change.
  if (password) body.password = password;
  if (clearNotes) body.notes = "";
  else if (notes) body.notes = notes;

  askConfirmation(
    t("confirm_save_credential"),
    (confirm_password) =>
      api(`/api/credentials/${credId}`, {
        method: "PUT",
        body: JSON.stringify({ ...body, confirm_password }),
      }),
    () => loadSites()
  );
}

function deleteCredential(credId) {
  const label = sitesCache.flatMap((e) => e.credentials).find((c) => c.id === credId)?.label || t("this_credential");
  askConfirmation(
    t("confirm_delete_credential", { name: label }),
    (confirm_password) => api(`/api/credentials/${credId}`, { method: "DELETE", body: JSON.stringify({ confirm_password }) }),
    () => {
      // Delete is only ever triggered from inside the modal in this design
      // — close it so it doesn't stay open referencing a now-deleted credential.
      document.getElementById("cred-modal")?.close();
      loadSites();
    }
  );
}

function deleteSite(siteId) {
  const entry = sitesCache.find((e) => e.site.id === siteId);
  const name = entry?.site.name || t("this_site");
  const count = entry?.credentials.length || 0;
  const warning = count > 0 ? t(count === 1 ? "delete_site_warning_one" : "delete_site_warning_other", { count }) : "";
  askConfirmation(
    t("confirm_delete_site", { name, warning }),
    (confirm_password) => api(`/api/sites/${siteId}`, { method: "DELETE", body: JSON.stringify({ confirm_password }) }),
    () => loadSites()
  );
}

// --- Panel de administración: Seguridad ---

async function loadSecuritySection() {
  const sec = await api("/api/admin/security");
  document.getElementById("sec-last-changed").textContent = sec.configured
    ? t("last_password_change", { date: new Date(sec.password_changed_at).toLocaleString() })
    : "";
  document.getElementById("sec-reminder-weeks").value = sec.reminder_weeks ?? 0;
  document.getElementById("sec-idle-timeout-minutes").value = sec.idle_timeout_minutes ?? 15;
  ["sec-current-password", "sec-new-password", "sec-new-question-1", "sec-new-answer-1", "sec-new-question-2", "sec-new-answer-2"].forEach(
    (id) => (document.getElementById(id).value = "")
  );
  document.getElementById("sec-password-error").textContent = "";
  document.getElementById("sec-reminder-error").textContent = "";
  document.getElementById("sec-idle-timeout-error").textContent = "";
}

async function changeMasterPassword() {
  const errEl = document.getElementById("sec-password-error");
  errEl.textContent = "";
  try {
    await api("/api/admin/password", {
      method: "PUT",
      body: JSON.stringify({
        current_password: document.getElementById("sec-current-password").value,
        new_password: document.getElementById("sec-new-password").value,
        new_question_1: document.getElementById("sec-new-question-1").value,
        new_answer_1: document.getElementById("sec-new-answer-1").value,
        new_question_2: document.getElementById("sec-new-question-2").value,
        new_answer_2: document.getElementById("sec-new-answer-2").value,
        confirm_message: CONFIRM_MESSAGE,
      }),
    });
    // The server already destroyed every session (same as a recovery
    // reset) — nothing left to keep using, so drop straight to login.
    show("login-section");
    document.getElementById("login-error").textContent = t("password_updated_success");
  } catch (e) {
    errEl.textContent = e.message;
  }
}

// --- Panel de administración: Autenticación en dos pasos (TOTP) ---

async function loadTOTPSection() {
  const statusLine = document.getElementById("totp-status-line");
  try {
    const status = await api("/api/admin/totp");
    renderTOTPState(status.enabled);
  } catch (e) {
    statusLine.textContent = e.message;
  }
}

function renderTOTPState(enabled) {
  document.getElementById("totp-status-line").textContent = enabled
    ? t("totp_enabled_status")
    : t("totp_disabled_status");
  document.getElementById("totp-disabled-panel").classList.toggle("js-hidden", enabled);
  document.getElementById("totp-enabled-panel").classList.toggle("js-hidden", !enabled);
  document.getElementById("totp-setup-panel").classList.add("js-hidden");
}

function startTOTPSetup() {
  askConfirmation(
    t("confirm_enable_totp"),
    (confirm_password) =>
      api("/api/admin/totp/setup", {
        method: "POST",
        body: JSON.stringify({ confirm_password, confirm_message: CONFIRM_MESSAGE }),
      }),
    (result) => {
      document.getElementById("totp-secret").value = result.secret;
      document.getElementById("totp-otpauth-url").value = result.otpauth_url;
      document.getElementById("totp-qr").src = result.qr_data_url;
      document.getElementById("totp-confirm-code").value = "";
      document.getElementById("totp-setup-error").textContent = "";
      document.getElementById("totp-disabled-panel").classList.add("js-hidden");
      document.getElementById("totp-enabled-panel").classList.add("js-hidden");
      document.getElementById("totp-setup-panel").classList.remove("js-hidden");
    }
  );
}

function cancelTOTPSetup() {
  loadTOTPSection();
}

async function confirmTOTPSetup() {
  const code = document.getElementById("totp-confirm-code").value;
  const errEl = document.getElementById("totp-setup-error");
  errEl.textContent = "";
  try {
    await api("/api/admin/totp/confirm", { method: "POST", body: JSON.stringify({ code }) });
    await loadTOTPSection();
  } catch (e) {
    errEl.textContent = e.message;
  }
}

function disableTOTP() {
  askConfirmation(
    t("confirm_disable_totp"),
    (confirm_password) =>
      api("/api/admin/totp/disable", {
        method: "POST",
        body: JSON.stringify({ confirm_password, confirm_message: CONFIRM_MESSAGE }),
      }),
    () => loadTOTPSection()
  );
}

function updateStatusLine(status) {
  const current = t("current_version_label", { v: status.current_version });
  if (!status.checked_at) return `${current} ${t("update_never_checked")}`;
  const when = new Date(status.checked_at).toLocaleString();
  if (status.update_available) return `${current} ${t("update_available_checked", { v: status.latest_version, when })}`;
  return `${current} ${t("update_up_to_date", { when })}`;
}

function renderUpdateAdminLink(status) {
  const link = document.getElementById("update-admin-link");
  if (status.latest_version) {
    link.classList.remove("js-hidden");
    link.href = status.latest_url || "#";
    link.textContent = t("view_version", { v: status.latest_version });
  } else {
    link.classList.add("js-hidden");
  }
}

async function loadUpdateSection() {
  document.getElementById("update-error").textContent = "";
  try {
    updateStatus = await api("/api/updates/status");
    document.getElementById("update-auto-check").checked = !!updateStatus.auto_check_enabled;
    document.getElementById("update-status-line").textContent = updateStatusLine(updateStatus);
    renderUpdateAdminLink(updateStatus);
    renderFooterVersion();
  } catch (e) {
    document.getElementById("update-status-line").textContent = "";
  }
}

async function toggleAutoUpdateCheck(checkbox) {
  const errEl = document.getElementById("update-error");
  errEl.textContent = "";
  try {
    updateStatus = await api("/api/updates/auto-check", {
      method: "PUT",
      body: JSON.stringify({ enabled: checkbox.checked }),
    });
    document.getElementById("update-status-line").textContent = updateStatusLine(updateStatus);
    renderFooterVersion();
  } catch (e) {
    checkbox.checked = !checkbox.checked; // revert on failure
    errEl.textContent = e.message;
  }
}

async function checkForUpdatesNow(btn) {
  const errEl = document.getElementById("update-error");
  errEl.textContent = "";
  const original = btn.textContent;
  btn.textContent = t("checking_ellipsis");
  btn.disabled = true;
  try {
    updateStatus = await api("/api/updates/check", { method: "POST" });
    document.getElementById("update-status-line").textContent = updateStatusLine(updateStatus);
    renderUpdateAdminLink(updateStatus);
    renderUpdateBanner();
  } catch (e) {
    errEl.textContent = e.message;
  } finally {
    btn.textContent = original;
    btn.disabled = false;
  }
}

// --- Panel de administración: Historial de accesos ---
//
// Solo lectura: pinta lo que ya devolvió el backend, no hay ninguna acción
// de borrar/editar una entrada desde aquí (el log es append-only).
async function loadAccessLog() {
  const list = document.getElementById("access-log-list");
  try {
    const entries = await api("/api/admin/access-log");
    if (!entries || entries.length === 0) {
      list.innerHTML = `<p class="muted">${t("no_access_log_entries")}</p>`;
      return;
    }
    list.innerHTML = entries
      .map((e) => {
        const verb = e.action === "copy" ? t("access_action_copy") : t("access_action_view");
        const when = new Date(e.accessed_at).toLocaleString();
        const label = escapeAttr(e.credential_label) || t("no_label");
        const entryText = t("access_log_entry", { who: escapeAttr(e.accessed_by), verb, label, site: escapeAttr(e.site_name), when });
        return `
        <div class="access-log-entry">
          <div class="cred-meta">${entryText}</div>
        </div>`;
      })
      .join("");
  } catch (e) {
    list.innerHTML = `<p class="error">${escapeAttr(e.message)}</p>`;
  }
}

async function saveReminderWeeks(btn) {
  const errEl = document.getElementById("sec-reminder-error");
  errEl.textContent = "";
  const weeks = parseInt(document.getElementById("sec-reminder-weeks").value, 10);
  if (isNaN(weeks) || weeks < 0) {
    errEl.textContent = t("reminder_weeks_invalid");
    return;
  }
  try {
    await api("/api/admin/security/reminder", { method: "PUT", body: JSON.stringify({ reminder_weeks: weeks }) });
    await refreshStatus();
    updatePasswordReminderBanner();
    const original = btn.textContent;
    btn.textContent = t("saved_check");
    setTimeout(() => (btn.textContent = original), 1500);
  } catch (e) {
    errEl.textContent = e.message;
  }
}

// Unlike saveReminderWeeks, this is a security-posture setting (how long
// an unlocked vault survives unattended), so it's gated through
// askConfirmation for a fresh master-password re-verification, mirroring
// disableTOTP's shape exactly instead of the reminder's ungated PUT.
function saveIdleTimeout(btn) {
  const errEl = document.getElementById("sec-idle-timeout-error");
  errEl.textContent = "";
  const minutes = parseInt(document.getElementById("sec-idle-timeout-minutes").value, 10);
  if (isNaN(minutes) || minutes < 1 || minutes > 1440) {
    errEl.textContent = t("idle_timeout_invalid");
    return;
  }
  askConfirmation(
    t("confirm_save_idle_timeout"),
    (confirm_password) =>
      api("/api/admin/security/idle-timeout", {
        method: "PUT",
        body: JSON.stringify({ minutes, confirm_password, confirm_message: CONFIRM_MESSAGE }),
      }),
    async () => {
      // loadSecuritySection() alone only refreshes the admin form's own
      // fields — the visible lock-pill countdown (renderLockPill) reads
      // the module-level idleTimeoutMs, which is only ever set inside
      // refreshStatus(). Without this, the new timeout is already live
      // server-side but the countdown keeps ticking down from the old
      // value until the next full page load.
      await refreshStatus();
      await loadSecuritySection();
    }
  );
}

// The export response is a file, not JSON, so it bypasses the shared api()
// helper (which assumes JSON) and does its own fetch + error handling.
// Success hands the blob to the browser's normal download flow — a web
// page can't write straight to a USB stick or external drive, but the
// browser's own "save as" dialog lets you pick exactly that location,
// same as saving any other download.
function exportBackup() {
  askConfirmation(
    t("confirm_export_backup"),
    async (confirm_password) => {
      const res = await fetch("/api/admin/export", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ confirm_password, confirm_message: CONFIRM_MESSAGE }),
      });
      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        throw new Error(translateApiError(body.error) || `error ${res.status}`);
      }
      return res;
    },
    async (res) => {
      const blob = await res.blob();
      const match = (res.headers.get("Content-Disposition") || "").match(/filename="?([^"]+)"?/);
      const filename = match ? match[1] : "surekey-backup.surekey";
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    }
  );
}

// Restoring a backup is destructive (wipes and replaces the whole vault),
// so unlike every other sensitive action it deliberately does NOT go
// through the shared #confirm-dialog (askConfirmation only asks for one
// password) — it needs its own visible panel with the backup file, the
// backup's own password, the live master password, and a hand-typed
// confirmation phrase, all left in place on failure so the user can fix
// just the field that was wrong without re-picking the file.
async function importBackup(btn) {
  const errEl = document.getElementById("import-error");
  errEl.textContent = "";

  const fileInput = document.getElementById("import-file");
  const file = fileInput.files[0];
  const backup_password = document.getElementById("import-backup-password").value;
  const confirm_password = document.getElementById("import-confirm-password").value;
  const confirm_message = document.getElementById("import-confirm-phrase").value;

  if (!file) {
    errEl.textContent = t("import_choose_file");
    return;
  }
  if (confirm_message !== IMPORT_CONFIRM_PHRASE) {
    errEl.textContent = t("import_confirm_phrase_hint", { phrase: IMPORT_CONFIRM_PHRASE });
    return;
  }

  btn.disabled = true;
  try {
    const backup_json = await file.text();
    const result = await api("/api/admin/import", {
      method: "POST",
      body: JSON.stringify({ backup_json, backup_password, confirm_password, confirm_message }),
    });
    errEl.textContent = t(result.sites_imported === 1 ? "import_success_one" : "import_success_other", { count: result.sites_imported });
    fileInput.value = "";
    document.getElementById("import-backup-password").value = "";
    document.getElementById("import-confirm-password").value = "";
    document.getElementById("import-confirm-phrase").value = "";
    await loadSites();
  } catch (e) {
    // Deliberately leave every field as-is on failure (including the
    // chosen file) so the user can correct just the one thing that was
    // wrong — e.g. a typo'd master password — and retry without having to
    // re-pick the file from disk.
    errEl.textContent = e.message;
  } finally {
    btn.disabled = false;
  }
}

init();
