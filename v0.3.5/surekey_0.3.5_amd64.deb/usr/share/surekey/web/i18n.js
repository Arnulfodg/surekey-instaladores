// web/i18n.js — diccionario compartido por index.html y terms.html.
// Sin selector de idioma real todavía tenías solo español; ahora cada
// string visible vive acá bajo una clave, con su texto en "es" y "en".
//
// Convenciones:
//  - Claves de UI: snake_case descriptivo en inglés.
//  - Claves de error del backend: prefijo "err_" + el código estable que
//    manda el backend en el campo "error" de la respuesta JSON (ver
//    internal/api/*.go — ese código no cambia según el idioma de la UI).
//  - t(key, vars) soporta interpolación simple "{nombre}" para armar
//    frases con datos dinámicos (nombres de sitio, contadores, fechas)
//    sin perder el orden de palabras correcto en cada idioma.
const I18N = {
  es: {
    // --- Selector de idioma ---
    lang_es: "ES",
    lang_en: "EN",

    // --- Configuración inicial (setup) ---
    setup_eyebrow: "Primer arranque",
    setup_title: "Configura tu bóveda",
    setup_hint:
      "Esto solo se pide una vez. La contraseña maestra nunca se guarda ni se puede recuperar: se usa para derivar la clave de cifrado. El correo es solo un dato de contacto, no permite restablecer el acceso si la olvidas.",
    label_full_name: "Nombre completo",
    placeholder_full_name: "Tu nombre",
    label_recovery_email: "Correo de contacto",
    placeholder_recovery_email: "tu@correo.com",
    label_master_password: "Contraseña maestra",
    placeholder_min12: "mín. 12 caracteres",
    setup_questions_hint:
      "Configura además 2 preguntas de seguridad para poder recuperar el acceso si olvidas la contraseña — incluyendo los datos ya guardados, no solo el acceso. Trátalas como una contraseña: usa una frase larga que solo tú conozcas, nunca un dato real adivinable (no \"nombre de tu mascota\" ni \"ciudad donde naciste\"). Mínimo 12 caracteres cada respuesta.",
    label_question_1: "Pregunta de seguridad 1",
    placeholder_question_1_example: "ej. ¿Cuál es tu frase secreta A?",
    label_question_2: "Pregunta de seguridad 2",
    placeholder_question_2_example: "ej. ¿Cuál es tu frase secreta B?",
    btn_create_vault: "Crear bóveda",

    // --- Login ---
    login_eyebrow: "Bóveda bloqueada",
    login_title: "Iniciar sesión",
    btn_unlock: "Desbloquear",
    btn_forgot_password: "¿Olvidaste tu contraseña?",
    totp_login_hint: "Introduce el código de 6 dígitos de tu app de autenticación.",
    label_code: "Código",
    btn_verify: "Verificar",
    btn_cancel: "Cancelar",

    // --- Recuperación ---
    recovery_eyebrow: "Recuperar acceso",
    recovery_title: "Responde tus preguntas de seguridad",
    recovery_hint: "Si respondes correctamente, se recuperan todos tus datos ya cifrados bajo una contraseña nueva — no se borra nada.",
    recovery_unavailable_hint: "No hay preguntas de recuperación configuradas para esta bóveda.",
    btn_back: "Volver",
    label_new_master_password: "Nueva contraseña maestra",
    recovery_new_questions_hint: "Ahora fija 2 preguntas de seguridad nuevas, por si vuelves a olvidarla.",
    label_new_question_1: "Nueva pregunta 1",
    label_new_question_2: "Nueva pregunta 2",
    btn_recover_access: "Recuperar acceso",

    // --- Bóveda (app-section) ---
    update_banner_available: "Hay una nueva versión de SureKey disponible",
    btn_view_download: "Ver descarga",
    btn_remind_later: "Recordar más tarde",
    password_reminder_text: "Llevas un tiempo sin cambiar tu contraseña maestra.",
    btn_go_security: "Ir a Seguridad",
    vault_eyebrow: "Bóveda",
    btn_admin: "⚙ Administración",
    btn_logout: "Cerrar sesión",
    placeholder_search: "buscar sitio, usuario o correo…",
    summary_add_site: "Añadir sitio",
    label_name: "Nombre",
    placeholder_site_name_example: "ej. Gmail",
    label_url_optional: "URL (opcional)",

    // --- Administración ---
    admin_eyebrow: "Administración",
    btn_back_to_vault: "← Volver a la bóveda",
    h2_security: "Seguridad",
    security_change_password_hint:
      "Cambia tu contraseña maestra. Debes escribir la contraseña actual para autorizarlo. Esto vuelve a cifrar todos los sitios y credenciales bajo la nueva contraseña, cierra todas las sesiones activas (tendrás que iniciar sesión de nuevo) y siempre pide fijar 2 preguntas de seguridad nuevas (puedes repetir las mismas si quieres).",
    label_current_password: "Contraseña actual",
    placeholder_current_master_password: "Contraseña maestra actual",
    security_fix_questions_hint: "Fija (o repite) las 2 preguntas de seguridad.",
    btn_change_password: "Cambiar contraseña",

    totp_intro_hint:
      "Añade un segundo factor: además de la contraseña maestra, pedirá un código de 6 dígitos generado por una app de autenticación (Google Authenticator, Aegis, etc.) para iniciar sesión. El secreto se cifra igual que cualquier otro dato de la bóveda. Si pierdes el dispositivo con la app, usa \"¿Olvidaste tu contraseña?\" en la pantalla de inicio de sesión — recuperar el acceso por ahí también desactiva el 2FA, y puedes volver a activarlo después desde aquí.",
    btn_enable_totp: "Activar 2FA",
    totp_setup_hint: "Ingresa esta clave manualmente en tu app de autenticación, o importa la URL completa donde tu app lo permita.",
    label_totp_secret: "Clave secreta (base32)",
    label_totp_url: "URL otpauth://",
    totp_qr_alt: "Código QR para escanear con tu app de autenticación",
    label_confirm_code: "Código de confirmación",
    btn_confirm: "Confirmar",
    btn_disable_totp: "Desactivar 2FA",

    reminder_hint: "Recibe un aviso en la bóveda cuando lleves demasiado tiempo sin cambiar la contraseña maestra. Pon 0 para desactivarlo.",
    label_remind_every_weeks: "Recordar cada (semanas)",
    btn_save_reminder: "Guardar recordatorio",

    h2_backup: "Copia de seguridad",
    export_hint:
      "Genera un archivo cifrado con todo lo guardado en la bóveda (sitios y credenciales) para guardarlo en un USB, disco externo, o donde prefieras — es una segunda copia fuera de este equipo. El archivo se cifra de nuevo, aparte, con una clave propia derivada de tu contraseña maestra: solo se puede abrir con esa contraseña, no depende de esta base de datos ni de este servidor. El navegador te dejará elegir dónde guardarlo, como cualquier descarga.",
    btn_export_backup: "Exportar copia cifrada",
    restore_hint_prefix: "Restaura la bóveda a partir de un archivo",
    restore_hint_suffix: "exportado antes.",
    restore_warning:
      "Atención: restaurar borra por completo todo lo que hay ahora en la bóveda (todos los sitios y credenciales) y lo reemplaza con el contenido del archivo. No es una fusión — lo que no esté en el backup desaparece.",
    label_backup_file: "Archivo de backup (.surekey)",
    label_backup_password: "Contraseña con la que se exportó ese backup",
    placeholder_backup_password: "Contraseña usada al exportar",
    label_current_master_password_field: "Tu contraseña maestra actual",
    label_import_confirm_phrase: "Escribe REEMPLAZAR TODO para confirmar",
    btn_restore_backup: "Restaurar copia",

    h2_updates: "Actualizaciones",
    updates_hint:
      "SureKey puede avisarte cuando exista una versión más reciente publicada en GitHub. La comprobación solo consulta el número de versión público del repositorio — no envía ningún dato tuyo ni de tu bóveda.",
    label_auto_check_updates: "Buscar actualizaciones automáticamente",
    btn_check_now: "Buscar ahora",

    h2_access_log: "Historial de accesos",
    access_log_hint:
      "Registro de solo lectura: cada vez que alguien ve o copia la contraseña de una credencial queda una entrada aquí. No se puede editar ni borrar directamente — desaparece solo si se elimina la credencial a la que pertenece.",

    // --- Diálogo de confirmación ---
    confirm_dialog_eyebrow: "Acción sensible",
    confirm_dialog_title: "Confirmar",
    confirm_default_subtitle: "Escribe tu contraseña maestra para confirmar.",

    // --- Generador de contraseñas ---
    generator_eyebrow: "Generador",
    generator_title: "Generar contraseña",
    label_length: "Longitud",
    label_lowercase: "minúsculas (a-z)",
    label_uppercase: "mayúsculas (A-Z)",
    label_digits: "números (0-9)",
    label_symbols: "símbolos (!@#$…)",
    label_preview: "Vista previa",
    regenerate_action: "Generar otra",
    btn_use_password: "Usar esta contraseña",

    // --- Pie de página ---
    footer_tagline: "cifrado localmente · argon2id + aes-256-gcm · sin servicios externos",
    footer_update_prefix: "Nueva versión disponible:",
    footer_update_suffix: "— Descargar",
    footer_legal_text: "Todos los derechos reservados. Creado por",
    link_terms: "Términos y condiciones",
    footer_donate_label: "💛 Donar con PayPal",

    // --- Popup de donación ---
    aria_donate_popup: "Apoya SureKey",
    aria_close: "Cerrar",
    donate_title: "¿Te resulta útil SureKey?",
    donate_text:
      "Es gratis, de código abierto, y sin servicios externos. Si te ha servido, considera invitarme un café — cada aporte ayuda a seguir mejorándolo.",
    btn_donate_paypal: "Donar con PayPal",
    donate_yappy_qr_heading: "Escanea el QR para donar",
    donate_yappy_qr_caption: "Invitarme un café me ayudaría a seguir creando más proyectos como este gratis",
    btn_not_now: "Ahora no, quizás luego",

    // --- Toggle mostrar/ocultar contraseña o respuesta (app.js) ---
    show_password: "Mostrar contraseña",
    hide_password: "Ocultar contraseña",
    view_password: "Ver contraseña",
    show_answer: "Mostrar respuesta",

    // --- Mensajes de sesión (app.js) ---
    session_expired_fallback: "Tu sesión expiró. Vuelve a iniciar sesión.",
    idle_timeout_message: "Tu sesión se cerró por inactividad. Vuelve a iniciar sesión.",
    password_reset_success: "Contraseña restablecida. Inicia sesión con la nueva.",
    password_updated_success: "Contraseña actualizada. Inicia sesión con la nueva.",
    lock_pill_locked: "bloqueada",
    lock_pill_unlocked: "desbloqueada · cierra en",

    // --- Contadores y textos genéricos (app.js) ---
    credential_singular: "credencial",
    credential_plural: "credenciales",
    no_label: "(sin etiqueta)",
    copy_password: "Copiar contraseña",
    edit: "Editar",
    delete_credential: "Eliminar credencial",
    delete_site: "Eliminar sitio y todas sus credenciales",
    add_credential_to: "Añadir credencial a",
    label_label: "Etiqueta",
    placeholder_label_example: "ej. cuenta admin",
    label_username: "Usuario",
    label_email: "Correo",
    label_password: "Contraseña",
    label_notes_optional: "Notas (opcional)",
    btn_save_credential: "Guardar credencial",
    editing_credential: "Editando credencial",
    placeholder_new_password: "Nueva contraseña",
    label_notes: "Notas",
    hint_leave_password_unchanged: "Deja este campo en blanco para no cambiar la contraseña actual.",
    label_clear_notes: "Borrar las notas actuales",
    btn_update_will_confirm: "Actualizar (pedirá confirmación)",
    gen_error_select_type: "Selecciona al menos un tipo de carácter.",
    copy_failed: "No se pudo copiar",
    copy_success: "Copiado",

    // --- Subtítulos del diálogo de confirmación (app.js) ---
    confirm_view_password: "Vas a ver esta contraseña. Escribe tu contraseña maestra para confirmar.",
    confirm_copy_password: "Vas a copiar esta contraseña al portapapeles. Escribe tu contraseña maestra para confirmar.",
    confirm_save_credential: "Vas a guardar los cambios de esta credencial. Escribe tu contraseña maestra para confirmar.",
    this_credential: "esta credencial",
    confirm_delete_credential: 'Vas a eliminar "{name}" de forma permanente. Escribe tu contraseña maestra para confirmar.',
    this_site: "este sitio",
    delete_site_warning_one: " y su {count} credencial",
    delete_site_warning_other: " y sus {count} credenciales",
    confirm_delete_site: 'Vas a eliminar "{name}"{warning} de forma permanente. Escribe tu contraseña maestra para confirmar.',
    confirm_export_backup:
      "Vas a exportar una copia cifrada de toda la bóveda (sitios y credenciales). Escribe tu contraseña maestra para confirmar.",
    confirm_enable_totp: "Vas a activar la autenticación en dos pasos. Escribe tu contraseña maestra para confirmar.",
    confirm_disable_totp: "Vas a desactivar la autenticación en dos pasos. Escribe tu contraseña maestra para confirmar.",

    // --- Estados dinámicos (app.js) ---
    last_password_change: "Última vez que cambiaste la contraseña: {date}.",
    totp_enabled_status: "Activado: se pedirá un código además de la contraseña maestra al iniciar sesión.",
    totp_disabled_status: "Desactivado.",
    current_version_label: "Versión actual: {v}.",
    update_never_checked: "Aún no se ha comprobado si hay una versión más reciente.",
    update_available_checked: "Hay una versión más reciente disponible: {v} (comprobado el {when}).",
    update_up_to_date: "Estás al día (comprobado el {when}).",
    view_version: "Ver {v}",
    checking_ellipsis: "Buscando…",
    reminder_weeks_invalid: "Introduce un número entero de semanas, 0 o mayor.",
    saved_check: "Guardado ✓",
    no_access_log_entries: "Todavía no hay accesos registrados.",
    access_action_view: "vio",
    access_action_copy: "copió",
    access_log_entry: '{who} {verb} "{label}" de {site} — {when}',
    import_choose_file: "Elige primero un archivo .surekey.",
    import_confirm_phrase_hint: 'Escribe exactamente "{phrase}" para confirmar.',
    import_success_one: "Restaurado: {count} sitio importado.",
    import_success_other: "Restaurado: {count} sitios importados.",
    tag_site: "Sitio",
    tag_credential: "Credencial",
    no_results: "Sin resultados",

    // --- Páginas de medios (fotos/videos/documentos/archivos.html + media.js) ---
    // Un solo grupo de páginas casi idénticas, diferenciadas solo por el
    // nombre visible de la categoría — ver el `data-category` de cada <body>.
    media_gate_eyebrow: "Sección protegida",
    media_gate_hint: "Ingresa la contraseña maestra para acceder a esta sección.",
    media_photo_title: "Fotos — SureKey",
    media_photo_heading: "Fotos",
    media_video_title: "Videos — SureKey",
    media_video_heading: "Videos",
    media_document_title: "Documentos — SureKey",
    media_document_heading: "Documentos",
    media_other_title: "Otros archivos — SureKey",
    media_other_heading: "Otros archivos",
    nav_menu_label: "Menú",
    nav_media_photo: "Fotos",
    nav_media_video: "Videos",
    nav_media_document: "Documentos",
    nav_media_other: "Otros archivos",
    media_status_locked: "bloqueada",
    media_status_unlocked: "desbloqueada",
    btn_media_backup: "Exportar copia",
    btn_media_restore: "Restaurar copia",
    media_new_folder_summary: "Nueva carpeta",
    media_folder_name_placeholder: "ej. Vacaciones 2026",
    btn_create_folder: "Crear carpeta",
    media_folders_heading: "Carpetas",
    media_no_folders: "Todavía no hay carpetas.",
    media_loose_heading: "Archivos sueltos",
    media_no_loose_files: "No hay archivos sueltos.",
    media_no_folder_files: "Esta carpeta está vacía.",
    media_upload_summary: "Subir archivos",
    btn_upload: "Subir",
    btn_delete: "Eliminar",
    btn_download: "Descargar",
    media_confirm_eyebrow: "Acción permanente",
    this_folder: "esta carpeta",
    this_file: "este archivo",
    media_confirm_delete_file_title: "¿Eliminar este archivo?",
    media_confirm_delete_file_body: 'Vas a eliminar «{name}» de forma permanente. Esta acción no se puede deshacer.',
    media_confirm_delete_folder_title: "¿Eliminar esta carpeta?",
    media_confirm_delete_folder_body:
      'Vas a eliminar la carpeta «{name}» y todo su contenido de forma permanente. Esta acción no se puede deshacer.',
    media_no_preview: "Sin vista previa disponible para este tipo de archivo.",
    media_restore_success_one: "Restaurado: {count} archivo importado.",
    media_restore_success_other: "Restaurado: {count} archivos importados.",

    // --- Términos y condiciones (terms.html) ---
    terms_page_title: "Términos y condiciones — SureKey",
    terms_back_link: "← Volver",
    terms_eyebrow: "Legal",
    terms_title: "Términos y condiciones de uso",
    terms_updated: "Última actualización: 25 de julio de 2026",
    terms_s1_title: "1. Aceptación",
    terms_s1_body:
      'Al descargar, instalar, desplegar o utilizar SureKey ("el Software"), usted acepta estos Términos y Condiciones en su totalidad. Si no está de acuerdo, no debe instalar ni utilizar el Software.',
    terms_s2_title: "2. Naturaleza del software",
    terms_s2_body:
      'SureKey es un gestor de credenciales de código fuente disponible, distribuido "TAL CUAL" ("AS IS"), sin garantía de ningún tipo, expresa o implícita, incluyendo sin limitación garantías de comerciabilidad, idoneidad para un propósito particular o ausencia de errores.',
    terms_s3_title: "3. Uso bajo su propia responsabilidad",
    terms_s3_intro: "Usted es el único responsable de:",
    terms_s3_li1:
      "Instalar, configurar, actualizar y asegurar el Software y todo el entorno donde lo despliegue (sistema operativo, red, cortafuegos, VPN/Tailscale u otro mecanismo de acceso remoto);",
    terms_s3_li2:
      "Elegir, resguardar y no divulgar su contraseña maestra, así como generar y proteger sus propias copias de seguridad;",
    terms_s3_li3: "Decidir si expone el Software a redes no confiables y bajo qué condiciones.",
    terms_s4_title: "4. Exclusión total de responsabilidad",
    terms_s4_callout:
      "En la máxima medida permitida por la ley aplicable, <strong>midesmis.com</strong>, su creador/fundador, y cualquier persona o entidad asociada al desarrollo de SureKey <strong>no serán responsables</strong>, bajo ninguna circunstancia, por daños directos, indirectos, incidentales, especiales, consecuentes o punitivos, ni por lucro cesante, pérdida de datos, pérdida o filtración de credenciales, ni ningún otro perjuicio derivado de:",
    terms_s4_li1: "El mal uso del Software por parte del usuario o de terceros;",
    terms_s4_li2: "Una configuración inadecuada, insegura o negligente del Software o de su entorno de despliegue;",
    terms_s4_li3:
      "La vulneración, explotación o compromiso de una instancia del Software por terceros, incluyendo ataques informáticos, explotación de vulnerabilidades conocidas o desconocidas, ingeniería social, o acceso no autorizado;",
    terms_s4_li4: "Modificaciones realizadas por el usuario o terceros al código fuente original;",
    terms_s4_li5: 'El uso del Software en contravención de estos Términos o de la <a href="../LICENSE">licencia</a> que lo acompaña.',
    terms_s4_footer:
      "El usuario reconoce que ningún software es infalible ni cien por ciento seguro, y asume voluntariamente todo el riesgo asociado a almacenar información sensible mediante SureKey.",
    terms_s5_title: "5. Indemnidad",
    terms_s5_body:
      "El usuario acepta mantener indemne a midesmis.com y a su creador/fundador frente a cualquier reclamo, demanda, pérdida o gasto (incluyendo honorarios legales razonables) que surja del uso del Software por el usuario o por terceros bajo su responsabilidad.",
    terms_s6_title: "6. Prohibición de uso comercial y reventa",
    terms_s6_callout:
      "SureKey se distribuye de forma libre y gratuita únicamente para uso personal, educativo o interno sin fines de lucro. Queda expresamente <strong>prohibido</strong>, sin autorización previa y por escrito de midesmis.com y de su representante, creador o fundador:",
    terms_s6_li1: "Vender, revender, sublicenciar o comercializar el Software o cualquier versión modificada de este;",
    terms_s6_li2: "Ofrecerlo como parte de un producto o servicio de pago, alojado o gestionado (SaaS) por un tercero;",
    terms_s6_li3:
      "Apropiarse, registrar como propio, o presentar el Software —total o parcialmente— como desarrollo propio de una empresa o persona distinta a su creador original.",
    terms_s6_footer:
      'Cualquier uso comercial no autorizado constituye una violación de estos Términos y de la licencia del Software. Para solicitar autorización, contacte a través de <a href="https://midesmis.com" target="_blank" rel="noopener noreferrer">midesmis.com</a>.',
    terms_s7_title: "7. Propiedad intelectual",
    terms_s7_body:
      "Todos los derechos, títulos e intereses sobre SureKey que no sean expresamente concedidos por la licencia incluida permanecen reservados a midesmis.com y su creador.",
    terms_s8_title: "8. Modificaciones a estos términos",
    terms_s8_body: "midesmis.com podrá actualizar estos Términos en cualquier momento. La versión vigente es siempre la publicada junto con el Software.",
    terms_s9_title: "9. Contacto",
    terms_s9_body:
      'Para solicitar autorización de uso comercial o por cualquier consulta relacionada con estos Términos: <a href="https://midesmis.com" target="_blank" rel="noopener noreferrer">midesmis.com</a>.',
    terms_footer_rights: "midesmis.com · todos los derechos reservados",

    // --- Códigos de error del backend (internal/api/*.go) ---
    err_internal_error: "Error interno",
    err_not_authenticated: "No autenticado",
    err_session_expired: "Sesión expirada, vuelve a iniciar sesión",
    err_too_many_attempts: "Demasiados intentos, espera unos minutos",
    err_invalid_request_body: "Cuerpo de la petición inválido",
    err_not_setup: "Primero configura la contraseña maestra",
    err_already_setup: "La contraseña maestra ya está configurada",
    err_full_name_required: "El nombre completo es obligatorio",
    err_invalid_recovery_email: "El correo de recuperación no es válido",
    err_password_too_weak: "La contraseña maestra debe tener al menos 12 caracteres",
    err_question_required: "Las dos preguntas son obligatorias",
    err_questions_identical: "Las dos preguntas deben ser distintas",
    err_answer_too_weak: "Cada respuesta debe tener al menos 12 caracteres",
    err_wrong_password: "Contraseña incorrecta",
    err_wrong_confirm_password: "Contraseña de confirmación incorrecta",
    err_wrong_current_password: "Contraseña actual incorrecta",
    err_confirm_message_required: "Debes escribir la frase de confirmación exacta",
    err_recovery_not_setup: "Las preguntas de recuperación no están configuradas",
    err_wrong_recovery_answers: "Respuestas de recuperación incorrectas",
    err_site_not_found: "Sitio no encontrado",
    err_credential_not_found: "Credencial no encontrada",
    err_name_and_created_by_required: "Nombre y quién lo creó son obligatorios",
    err_password_and_created_by_required: "Contraseña y quién lo creó son obligatorios",
    err_updated_by_required: "Quién lo actualizó es obligatorio",
    err_password_required: "La contraseña es obligatoria",
    err_name_required: "El nombre es obligatorio",
    err_invalid_reminder_weeks: "El intervalo de recordatorio debe ser cero o un entero positivo",
    err_invalid_code: "Código incorrecto",
    err_totp_not_set_up: "Primero activa el 2FA para obtener un código de configuración",
    err_update_check_not_configured: "La comprobación de actualizaciones aún no está configurada",
    err_update_check_failed: "No se pudo contactar a GitHub para comprobar actualizaciones",
    err_invalid_backup_file: "El archivo no es un backup de SureKey válido",
    err_unsupported_backup_version: "El backup tiene un formato no soportado",
    err_backup_decryption_failed: "No se pudo descifrar el backup — revisa la contraseña con la que se exportó",
    // Nota: la frase entre comillas es un literal de seguridad que el backend
    // compara tal cual — se mantiene en español en ambos idiomas a propósito
    // (ver la clave equivalente en "en" más abajo).
    err_import_confirm_phrase_required: 'Debes escribir exactamente "REEMPLAZAR TODO" para confirmar',

    // --- Códigos de error del backend: sección de medios (internal/api/media.go) ---
    err_invalid_category: "Categoría no válida",
    err_folder_not_found: "Carpeta no encontrada",
    err_file_and_created_by_required: "El archivo y quién lo subió son obligatorios",
    err_file_too_large: "El archivo supera el tamaño máximo permitido (8 GiB)",
    err_backup_and_created_by_required: "El archivo de backup y quién lo restauró son obligatorios",
    err_file_not_found: "Archivo no encontrado",
    // No debería mostrarse nunca al usuario — un 404 de la miniatura se trata
    // en silencio como "sin vista previa disponible" (ver media.js), esta
    // clave solo existe por completitud de la tabla de errores.
    err_thumbnail_not_available: "Miniatura no disponible",
  },

  en: {
    // --- Language switcher ---
    lang_es: "ES",
    lang_en: "EN",

    // --- Initial setup ---
    setup_eyebrow: "First start",
    setup_title: "Set up your vault",
    setup_hint:
      "This is only asked once. The master password is never stored and can't be recovered — it's used to derive the encryption key. The email is just a contact detail; it doesn't let you restore access if you forget your password.",
    label_full_name: "Full name",
    placeholder_full_name: "Your name",
    label_recovery_email: "Contact email",
    placeholder_recovery_email: "you@email.com",
    label_master_password: "Master password",
    placeholder_min12: "min. 12 characters",
    setup_questions_hint:
      "Also set up 2 security questions so you can recover access if you forget the password — including the data already stored, not just access. Treat them like a password: use a long phrase only you know, never a real guessable fact (not \"your pet's name\" or \"city you were born in\"). Minimum 12 characters per answer.",
    label_question_1: "Security question 1",
    placeholder_question_1_example: "e.g. What's your secret phrase A?",
    label_question_2: "Security question 2",
    placeholder_question_2_example: "e.g. What's your secret phrase B?",
    btn_create_vault: "Create vault",

    // --- Login ---
    login_eyebrow: "Vault locked",
    login_title: "Log in",
    btn_unlock: "Unlock",
    btn_forgot_password: "Forgot your password?",
    totp_login_hint: "Enter the 6-digit code from your authenticator app.",
    label_code: "Code",
    btn_verify: "Verify",
    btn_cancel: "Cancel",

    // --- Recovery ---
    recovery_eyebrow: "Recover access",
    recovery_title: "Answer your security questions",
    recovery_hint: "If you answer correctly, all your already-encrypted data is recovered under a new password — nothing gets deleted.",
    recovery_unavailable_hint: "No recovery questions are configured for this vault.",
    btn_back: "Back",
    label_new_master_password: "New master password",
    recovery_new_questions_hint: "Now set 2 new security questions, in case you forget it again.",
    label_new_question_1: "New question 1",
    label_new_question_2: "New question 2",
    btn_recover_access: "Recover access",

    // --- Vault (app-section) ---
    update_banner_available: "A new version of SureKey is available",
    btn_view_download: "View download",
    btn_remind_later: "Remind me later",
    password_reminder_text: "It's been a while since you changed your master password.",
    btn_go_security: "Go to Security",
    vault_eyebrow: "Vault",
    btn_admin: "⚙ Administration",
    btn_logout: "Log out",
    placeholder_search: "search site, username, or email…",
    summary_add_site: "Add site",
    label_name: "Name",
    placeholder_site_name_example: "e.g. Gmail",
    label_url_optional: "URL (optional)",

    // --- Administration ---
    admin_eyebrow: "Administration",
    btn_back_to_vault: "← Back to vault",
    h2_security: "Security",
    security_change_password_hint:
      "Change your master password. You must type the current password to authorize it. This re-encrypts every site and credential under the new password, closes every active session (you'll need to log in again), and always requires setting 2 new security questions (you can repeat the same ones if you want).",
    label_current_password: "Current password",
    placeholder_current_master_password: "Current master password",
    security_fix_questions_hint: "Set (or repeat) the 2 security questions.",
    btn_change_password: "Change password",

    totp_intro_hint:
      "Add a second factor: besides the master password, it will ask for a 6-digit code generated by an authenticator app (Google Authenticator, Aegis, etc.) to log in. The secret is encrypted just like any other vault data. If you lose the device with the app, use \"Forgot your password?\" on the login screen — recovering access that way also disables 2FA, and you can turn it back on afterward from here.",
    btn_enable_totp: "Enable 2FA",
    totp_setup_hint: "Enter this key manually in your authenticator app, or import the full URL where your app supports it.",
    label_totp_secret: "Secret key (base32)",
    label_totp_url: "otpauth:// URL",
    totp_qr_alt: "QR code to scan with your authenticator app",
    label_confirm_code: "Confirmation code",
    btn_confirm: "Confirm",
    btn_disable_totp: "Disable 2FA",

    reminder_hint: "Get a notice in the vault when it's been too long since you changed your master password. Set it to 0 to turn it off.",
    label_remind_every_weeks: "Remind every (weeks)",
    btn_save_reminder: "Save reminder",

    h2_backup: "Backup",
    export_hint:
      "Generates an encrypted file with everything stored in the vault (sites and credentials) so you can keep it on a USB drive, external disk, or wherever you prefer — it's a second copy outside this machine. The file is encrypted again, separately, with its own key derived from your master password: it can only be opened with that password, and doesn't depend on this database or this server. The browser will let you choose where to save it, like any other download.",
    btn_export_backup: "Export encrypted backup",
    restore_hint_prefix: "Restore the vault from a",
    restore_hint_suffix: "file you exported before.",
    restore_warning:
      "Warning: restoring completely erases everything currently in the vault (every site and credential) and replaces it with the contents of the file. It's not a merge — anything not in the backup disappears.",
    label_backup_file: "Backup file (.surekey)",
    label_backup_password: "Password used to export that backup",
    placeholder_backup_password: "Password used when exporting",
    label_current_master_password_field: "Your current master password",
    label_import_confirm_phrase: "Type REEMPLAZAR TODO to confirm",
    btn_restore_backup: "Restore backup",

    h2_updates: "Updates",
    updates_hint:
      "SureKey can notify you when a newer version is published on GitHub. The check only queries the repository's public version number — it doesn't send any of your data or vault contents.",
    label_auto_check_updates: "Check for updates automatically",
    btn_check_now: "Check now",

    h2_access_log: "Access log",
    access_log_hint:
      "Read-only record: every time someone views or copies a credential's password, an entry is logged here. It can't be edited or deleted directly — it only disappears if the credential it belongs to is deleted.",

    // --- Confirmation dialog ---
    confirm_dialog_eyebrow: "Sensitive action",
    confirm_dialog_title: "Confirm",
    confirm_default_subtitle: "Type your master password to confirm.",

    // --- Password generator ---
    generator_eyebrow: "Generator",
    generator_title: "Generate password",
    label_length: "Length",
    label_lowercase: "lowercase (a-z)",
    label_uppercase: "uppercase (A-Z)",
    label_digits: "numbers (0-9)",
    label_symbols: "symbols (!@#$…)",
    label_preview: "Preview",
    regenerate_action: "Generate another",
    btn_use_password: "Use this password",

    // --- Footer ---
    footer_tagline: "encrypted locally · argon2id + aes-256-gcm · no external services",
    footer_update_prefix: "New version available:",
    footer_update_suffix: "— Download",
    footer_legal_text: "All rights reserved. Created by",
    link_terms: "Terms and conditions",
    footer_donate_label: "💛 Donate with PayPal",

    // --- Donate popup ---
    aria_donate_popup: "Support SureKey",
    aria_close: "Close",
    donate_title: "Finding SureKey useful?",
    donate_text:
      "It's free, open source, and doesn't rely on any external services. If it's been useful to you, consider buying me a coffee — every bit helps keep improving it.",
    btn_donate_paypal: "Donate with PayPal",
    donate_yappy_qr_heading: "Scan the QR code to donate",
    donate_yappy_qr_caption: "Buying me a coffee would help me keep creating more free projects like this one",
    btn_not_now: "Not now, maybe later",

    // --- Show/hide password or answer toggle (app.js) ---
    show_password: "Show password",
    hide_password: "Hide password",
    view_password: "View password",
    show_answer: "Show answer",

    // --- Session messages (app.js) ---
    session_expired_fallback: "Your session expired. Please log in again.",
    idle_timeout_message: "Your session was closed due to inactivity. Please log in again.",
    password_reset_success: "Password reset. Log in with the new one.",
    password_updated_success: "Password updated. Log in with the new one.",
    lock_pill_locked: "locked",
    lock_pill_unlocked: "unlocked · locks in",

    // --- Generic counters and labels (app.js) ---
    credential_singular: "credential",
    credential_plural: "credentials",
    no_label: "(no label)",
    copy_password: "Copy password",
    edit: "Edit",
    delete_credential: "Delete credential",
    delete_site: "Delete site and all its credentials",
    add_credential_to: "Add credential to",
    label_label: "Label",
    placeholder_label_example: "e.g. admin account",
    label_username: "Username",
    label_email: "Email",
    label_password: "Password",
    label_notes_optional: "Notes (optional)",
    btn_save_credential: "Save credential",
    editing_credential: "Editing credential",
    placeholder_new_password: "New password",
    label_notes: "Notes",
    hint_leave_password_unchanged: "Leave this field blank to keep the current password.",
    label_clear_notes: "Clear the current notes",
    btn_update_will_confirm: "Update (will ask for confirmation)",
    gen_error_select_type: "Select at least one character type.",
    copy_failed: "Couldn't copy",
    copy_success: "Copied",

    // --- Confirmation dialog subtitles (app.js) ---
    confirm_view_password: "You're about to view this password. Type your master password to confirm.",
    confirm_copy_password: "You're about to copy this password to the clipboard. Type your master password to confirm.",
    confirm_save_credential: "You're about to save the changes to this credential. Type your master password to confirm.",
    this_credential: "this credential",
    confirm_delete_credential: 'You\'re about to permanently delete "{name}". Type your master password to confirm.',
    this_site: "this site",
    delete_site_warning_one: " and its {count} credential",
    delete_site_warning_other: " and its {count} credentials",
    confirm_delete_site: 'You\'re about to permanently delete "{name}"{warning}. Type your master password to confirm.',
    confirm_export_backup:
      "You're about to export an encrypted copy of the whole vault (sites and credentials). Type your master password to confirm.",
    confirm_enable_totp: "You're about to enable two-step authentication. Type your master password to confirm.",
    confirm_disable_totp: "You're about to disable two-step authentication. Type your master password to confirm.",

    // --- Dynamic status text (app.js) ---
    last_password_change: "Last time you changed your password: {date}.",
    totp_enabled_status: "Enabled: a code will be required in addition to the master password when logging in.",
    totp_disabled_status: "Disabled.",
    current_version_label: "Current version: {v}.",
    update_never_checked: "Whether a newer version exists hasn't been checked yet.",
    update_available_checked: "A newer version is available: {v} (checked on {when}).",
    update_up_to_date: "You're up to date (checked on {when}).",
    view_version: "View {v}",
    checking_ellipsis: "Checking…",
    reminder_weeks_invalid: "Enter a whole number of weeks, 0 or greater.",
    saved_check: "Saved ✓",
    no_access_log_entries: "No accesses recorded yet.",
    access_action_view: "viewed",
    access_action_copy: "copied",
    access_log_entry: '{who} {verb} "{label}" from {site} — {when}',
    import_choose_file: "Choose a .surekey file first.",
    import_confirm_phrase_hint: 'Type exactly "{phrase}" to confirm.',
    import_success_one: "Restored: {count} site imported.",
    import_success_other: "Restored: {count} sites imported.",
    tag_site: "Site",
    tag_credential: "Credential",
    no_results: "No results",

    // --- Media pages (fotos/videos/documentos/archivos.html + media.js) ---
    media_gate_eyebrow: "Protected section",
    media_gate_hint: "Enter the master password to access this section.",
    media_photo_title: "Photos — SureKey",
    media_photo_heading: "Photos",
    media_video_title: "Videos — SureKey",
    media_video_heading: "Videos",
    media_document_title: "Documents — SureKey",
    media_document_heading: "Documents",
    media_other_title: "Other files — SureKey",
    media_other_heading: "Other files",
    nav_menu_label: "Menu",
    nav_media_photo: "Photos",
    nav_media_video: "Videos",
    nav_media_document: "Documents",
    nav_media_other: "Other files",
    media_status_locked: "locked",
    media_status_unlocked: "unlocked",
    btn_media_backup: "Export backup",
    btn_media_restore: "Restore backup",
    media_new_folder_summary: "New folder",
    media_folder_name_placeholder: "e.g. Vacation 2026",
    btn_create_folder: "Create folder",
    media_folders_heading: "Folders",
    media_no_folders: "No folders yet.",
    media_loose_heading: "Unfiled files",
    media_no_loose_files: "No unfiled files.",
    media_no_folder_files: "This folder is empty.",
    media_upload_summary: "Upload files",
    btn_upload: "Upload",
    btn_delete: "Delete",
    btn_download: "Download",
    media_confirm_eyebrow: "Permanent action",
    this_folder: "this folder",
    this_file: "this file",
    media_confirm_delete_file_title: "Delete this file?",
    media_confirm_delete_file_body: 'You are about to permanently delete "{name}". This action cannot be undone.',
    media_confirm_delete_folder_title: "Delete this folder?",
    media_confirm_delete_folder_body:
      'You are about to permanently delete the folder "{name}" and everything inside it. This action cannot be undone.',
    media_no_preview: "No preview available for this type of file.",
    media_restore_success_one: "Restored: {count} file imported.",
    media_restore_success_other: "Restored: {count} files imported.",

    // --- Terms and conditions (terms.html) ---
    terms_page_title: "Terms and conditions — SureKey",
    terms_back_link: "← Back",
    terms_eyebrow: "Legal",
    terms_title: "Terms and Conditions of Use",
    terms_updated: "Last updated: July 25, 2026",
    terms_s1_title: "1. Acceptance",
    terms_s1_body:
      'By downloading, installing, deploying, or using SureKey ("the Software"), you accept these Terms and Conditions in full. If you do not agree, you must not install or use the Software.',
    terms_s2_title: "2. Nature of the software",
    terms_s2_body:
      'SureKey is a source-available credential manager, distributed "AS IS", without warranty of any kind, express or implied, including without limitation warranties of merchantability, fitness for a particular purpose, or absence of errors.',
    terms_s3_title: "3. Use at your own risk",
    terms_s3_intro: "You are solely responsible for:",
    terms_s3_li1:
      "Installing, configuring, updating, and securing the Software and the entire environment where you deploy it (operating system, network, firewall, VPN/Tailscale, or any other remote-access mechanism);",
    terms_s3_li2: "Choosing, safeguarding, and not disclosing your master password, as well as generating and protecting your own backups;",
    terms_s3_li3: "Deciding whether to expose the Software to untrusted networks and under what conditions.",
    terms_s4_title: "4. Total exclusion of liability",
    terms_s4_callout:
      "To the maximum extent permitted by applicable law, <strong>midesmis.com</strong>, its creator/founder, and any person or entity associated with the development of SureKey <strong>will not be liable</strong>, under any circumstances, for direct, indirect, incidental, special, consequential, or punitive damages, nor for lost profits, data loss, loss or leakage of credentials, nor any other harm arising from:",
    terms_s4_li1: "Misuse of the Software by the user or by third parties;",
    terms_s4_li2: "Inadequate, insecure, or negligent configuration of the Software or of its deployment environment;",
    terms_s4_li3:
      "The breach, exploitation, or compromise of an instance of the Software by third parties, including cyberattacks, exploitation of known or unknown vulnerabilities, social engineering, or unauthorized access;",
    terms_s4_li4: "Modifications made by the user or third parties to the original source code;",
    terms_s4_li5: 'Use of the Software in violation of these Terms or of the <a href="../LICENSE">license</a> that accompanies it.',
    terms_s4_footer:
      "The user acknowledges that no software is infallible or one hundred percent secure, and voluntarily assumes all risk associated with storing sensitive information through SureKey.",
    terms_s5_title: "5. Indemnity",
    terms_s5_body:
      "The user agrees to hold midesmis.com and its creator/founder harmless from any claim, demand, loss, or expense (including reasonable legal fees) arising from use of the Software by the user or by third parties under their responsibility.",
    terms_s6_title: "6. Prohibition of commercial use and resale",
    terms_s6_callout:
      "SureKey is distributed free of charge solely for personal, educational, or nonprofit internal use. Without prior written authorization from midesmis.com and its representative, creator, or founder, it is expressly <strong>prohibited</strong> to:",
    terms_s6_li1: "Sell, resell, sublicense, or commercialize the Software or any modified version of it;",
    terms_s6_li2: "Offer it as part of a paid, hosted, or managed (SaaS) product or service by a third party;",
    terms_s6_li3:
      "Appropriate, register as one's own, or present the Software — in whole or in part — as the original work of a company or person other than its original creator.",
    terms_s6_footer:
      'Any unauthorized commercial use constitutes a violation of these Terms and of the Software\'s license. To request authorization, get in touch via <a href="https://midesmis.com" target="_blank" rel="noopener noreferrer">midesmis.com</a>.',
    terms_s7_title: "7. Intellectual property",
    terms_s7_body:
      "All rights, titles, and interests in SureKey not expressly granted by the included license remain reserved to midesmis.com and its creator.",
    terms_s8_title: "8. Changes to these terms",
    terms_s8_body: "midesmis.com may update these Terms at any time. The version in force is always the one published alongside the Software.",
    terms_s9_title: "9. Contact",
    terms_s9_body:
      'To request authorization for commercial use or for any inquiry related to these Terms: <a href="https://midesmis.com" target="_blank" rel="noopener noreferrer">midesmis.com</a>.',
    terms_footer_rights: "midesmis.com · all rights reserved",

    // --- Backend error codes (internal/api/*.go) ---
    err_internal_error: "Internal error",
    err_not_authenticated: "Not authenticated",
    err_session_expired: "Session expired, please log in again",
    err_too_many_attempts: "Too many attempts, wait a few minutes",
    err_invalid_request_body: "Invalid request body",
    err_not_setup: "Set up your master password first",
    err_already_setup: "The master password is already configured",
    err_full_name_required: "Full name is required",
    err_invalid_recovery_email: "The recovery email isn't valid",
    err_password_too_weak: "The master password must be at least 12 characters",
    err_question_required: "Both questions are required",
    err_questions_identical: "The two questions must be different",
    err_answer_too_weak: "Each answer must be at least 12 characters",
    err_wrong_password: "Incorrect password",
    err_wrong_confirm_password: "Incorrect confirmation password",
    err_wrong_current_password: "Incorrect current password",
    err_confirm_message_required: "You must type the exact confirmation phrase",
    err_recovery_not_setup: "Recovery questions aren't configured",
    err_wrong_recovery_answers: "Incorrect recovery answers",
    err_site_not_found: "Site not found",
    err_credential_not_found: "Credential not found",
    err_name_and_created_by_required: "Name and creator are required",
    err_password_and_created_by_required: "Password and creator are required",
    err_updated_by_required: "Updater is required",
    err_password_required: "Password is required",
    err_name_required: "Name is required",
    err_invalid_reminder_weeks: "The reminder interval must be zero or a positive integer",
    err_invalid_code: "Incorrect code",
    err_totp_not_set_up: "Enable 2FA first to get a setup code",
    err_update_check_not_configured: "The update check isn't configured yet",
    err_update_check_failed: "Couldn't reach GitHub to check for updates",
    err_invalid_backup_file: "The file isn't a valid SureKey backup",
    err_unsupported_backup_version: "The backup has an unsupported format",
    err_backup_decryption_failed: "Couldn't decrypt the backup — check the password it was exported with",
    // Note: the quoted phrase is a security literal the backend compares
    // verbatim — it deliberately stays in Spanish in the English dictionary
    // too (see CLAUDE.md / the task instructions for why).
    err_import_confirm_phrase_required: 'You must type exactly "REEMPLAZAR TODO" to confirm',

    // --- Backend error codes: media section (internal/api/media.go) ---
    err_invalid_category: "Invalid category",
    err_folder_not_found: "Folder not found",
    err_file_and_created_by_required: "File and uploader are required",
    err_file_too_large: "The file exceeds the maximum allowed size (8 GiB)",
    err_backup_and_created_by_required: "Backup file and restorer are required",
    err_file_not_found: "File not found",
    // Should never surface to the user — a thumbnail 404 is silently treated
    // as "no preview available" (see media.js); this key only exists for
    // completeness of the error table.
    err_thumbnail_not_available: "Thumbnail not available",
  },
};

const LANG_STORAGE_KEY = "surekey_lang";

function getLang() {
  const stored = localStorage.getItem(LANG_STORAGE_KEY);
  if (stored === "es" || stored === "en") return stored;
  return navigator.language && navigator.language.startsWith("en") ? "en" : "es";
}

function setLang(lang) {
  localStorage.setItem(LANG_STORAGE_KEY, lang);
  applyTranslations();
  if (typeof onLangChanged === "function") onLangChanged(); // index.html defines this to re-render dynamic content; terms.html doesn't need it and the call is a no-op there
}

// t(key, vars) translates a UI key to the active language, falling back to
// Spanish, then English, then the raw key itself (so a missing translation
// is visible during development instead of leaving a blank spot on screen).
// `vars`, if given, does simple "{name}" interpolation for dynamic values
// (site names, counters, dates) without breaking word order per language.
function t(key, vars) {
  const lang = getLang();
  let str = (I18N[lang] && I18N[lang][key]) ?? I18N.es[key] ?? I18N.en[key] ?? key;
  if (vars) {
    for (const [k, v] of Object.entries(vars)) str = str.replaceAll(`{${k}}`, v);
  }
  return str;
}

// translateApiError(code) is the same fallback chain as t(), but scoped to
// the "err_" namespace and tolerant of a missing/unknown code — the backend
// is only ever expected to send codes from the table above, but if it ever
// sends something new (or nothing), this degrades to showing the raw code
// (or null) instead of throwing or leaving the error blank.
function translateApiError(code) {
  if (!code) return null;
  const key = "err_" + code;
  const lang = getLang();
  return (I18N[lang] && I18N[lang][key]) ?? I18N.es[key] ?? I18N.en[key] ?? code;
}

// applyTranslations walks the DOM applying the active language — called on
// page load and every time the language changes.
function applyTranslations() {
  document.documentElement.lang = getLang();
  document.querySelectorAll("[data-i18n]").forEach((el) => { el.textContent = t(el.dataset.i18n); });
  document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => { el.placeholder = t(el.dataset.i18nPlaceholder); });
  document.querySelectorAll("[data-i18n-aria-label]").forEach((el) => { el.setAttribute("aria-label", t(el.dataset.i18nAriaLabel)); });
  document.querySelectorAll("[data-i18n-title]").forEach((el) => { el.title = t(el.dataset.i18nTitle); });
  document.querySelectorAll("[data-i18n-html]").forEach((el) => { el.innerHTML = t(el.dataset.i18nHtml); });
  document.querySelectorAll("[data-i18n-alt]").forEach((el) => { el.alt = t(el.dataset.i18nAlt); });
  document.querySelectorAll("[data-lang-btn]").forEach((el) => {
    el.classList.toggle("active", el.dataset.langBtn === getLang());
  });
}

applyTranslations();
